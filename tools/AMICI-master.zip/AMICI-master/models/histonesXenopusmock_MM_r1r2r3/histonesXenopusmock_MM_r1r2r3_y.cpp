
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void y_histonesXenopusmock_MM_r1r2r3(double *y, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w) {
  y[0] = -amici::log(x[0]+x[1]+x[2]+x[3])+amici::log(x[0]);
  y[1] = -amici::log(x[0]+x[1]+x[2]+x[3])+amici::log(x[1]);
  y[2] = -amici::log(x[0]+x[1]+x[2]+x[3])+amici::log(x[2]);
  y[3] = -amici::log(x[0]+x[1]+x[2]+x[3])+amici::log(x[3]);
}

