
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void JDiag_histonesXenopusmock_MM_r1r2r3(realtype *JDiag, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w, const realtype *dwdx) {
  JDiag[0+0*4] = -p[6]-w[5]*w[10]+6.243314768165359E15/((t*p[0]*9.007199254740992E15)/w[0]+4.503599627370496E15);
  JDiag[1+0*4] = -p[7]-w[5]*w[10];
  JDiag[2+0*4] = -p[8]-w[5]*w[10];
  JDiag[3+0*4] = -w[5]*w[10];
}

