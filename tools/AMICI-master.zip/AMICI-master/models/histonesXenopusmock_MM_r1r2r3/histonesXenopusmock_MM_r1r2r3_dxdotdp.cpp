
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void dxdotdp_histonesXenopusmock_MM_r1r2r3(realtype *dxdotdp, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const int ip, const realtype *w, const realtype *dwdp) {
switch (ip) {
  case 0: {
  dxdotdp[0] = -x[0]*w[5]*dwdp[4]-x[0]*w[10]*dwdp[1]-(t*1.0/pow((t*p[0]*9.007199254740992E15)/w[0]+4.503599627370496E15,2.0)*(x[0]*6.243314768165359E15+x[1]*6.243314768165359E15+x[2]*6.243314768165359E15+x[3]*6.243314768165359E15)*9.007199254740992E15)/w[0];
  dxdotdp[1] = -x[1]*w[5]*dwdp[4]-x[1]*w[10]*dwdp[1];
  dxdotdp[2] = -x[2]*w[5]*dwdp[4]-x[2]*w[10]*dwdp[1];
  dxdotdp[3] = -x[3]*w[5]*dwdp[4]-x[3]*w[10]*dwdp[1];

  } break;

  case 1: {
  dxdotdp[0] = -x[0]*w[5]*dwdp[11]-x[0]*w[10]*dwdp[8]+t*p[0]*1.0/(w[0]*w[0])*dwdp[5]*1.0/pow((t*p[0]*9.007199254740992E15)/w[0]+4.503599627370496E15,2.0)*(x[0]*6.243314768165359E15+x[1]*6.243314768165359E15+x[2]*6.243314768165359E15+x[3]*6.243314768165359E15)*9.007199254740992E15;
  dxdotdp[1] = -x[1]*w[5]*dwdp[11]-x[1]*w[10]*dwdp[8];
  dxdotdp[2] = -x[2]*w[5]*dwdp[11]-x[2]*w[10]*dwdp[8];
  dxdotdp[3] = -x[3]*w[5]*dwdp[11]-x[3]*w[10]*dwdp[8];

  } break;

  case 6: {
  dxdotdp[0] = -x[0];
  dxdotdp[1] = x[0];

  } break;

  case 7: {
  dxdotdp[1] = -x[1];
  dxdotdp[2] = x[1];

  } break;

  case 8: {
  dxdotdp[2] = -x[2];
  dxdotdp[3] = x[2];

  } break;

}
}

