
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void dwdp_histones_standardDemeth_all(realtype *dwdp, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w, const realtype *tcl, const realtype *stcl) {
  dwdp[0] = x[4];
  dwdp[1] = x[5];
  dwdp[2] = x[6];
  dwdp[3] = x[7];
  dwdp[4] = x[19];
  dwdp[5] = x[20];
  dwdp[6] = x[21];
  dwdp[7] = x[22];
  dwdp[8] = x[34];
  dwdp[9] = x[35];
  dwdp[10] = x[36];
  dwdp[11] = x[37];
  dwdp[12] = x[8];
  dwdp[13] = x[9];
  dwdp[14] = x[10];
  dwdp[15] = x[11];
  dwdp[16] = x[23];
  dwdp[17] = x[24];
  dwdp[18] = x[25];
  dwdp[19] = x[26];
  dwdp[20] = x[38];
  dwdp[21] = x[39];
  dwdp[22] = x[40];
  dwdp[23] = x[41];
  dwdp[24] = x[12];
  dwdp[25] = x[13];
  dwdp[26] = x[14];
  dwdp[27] = x[27];
  dwdp[28] = x[28];
  dwdp[29] = x[29];
  dwdp[30] = x[42];
  dwdp[31] = x[43];
  dwdp[32] = x[44];
  dwdp[33] = x[1];
  dwdp[34] = x[5];
  dwdp[35] = x[9];
  dwdp[36] = x[13];
  dwdp[37] = x[16];
  dwdp[38] = x[20];
  dwdp[39] = x[24];
  dwdp[40] = x[28];
  dwdp[41] = x[31];
  dwdp[42] = x[35];
  dwdp[43] = x[39];
  dwdp[44] = x[43];
  dwdp[45] = x[2];
  dwdp[46] = x[6];
  dwdp[47] = x[10];
  dwdp[48] = x[14];
  dwdp[49] = x[17];
  dwdp[50] = x[21];
  dwdp[51] = x[25];
  dwdp[52] = x[29];
  dwdp[53] = x[32];
  dwdp[54] = x[36];
  dwdp[55] = x[40];
  dwdp[56] = x[44];
  dwdp[57] = x[3];
  dwdp[58] = x[7];
  dwdp[59] = x[11];
  dwdp[60] = x[18];
  dwdp[61] = x[22];
  dwdp[62] = x[26];
  dwdp[63] = x[33];
  dwdp[64] = x[37];
  dwdp[65] = x[41];
}

