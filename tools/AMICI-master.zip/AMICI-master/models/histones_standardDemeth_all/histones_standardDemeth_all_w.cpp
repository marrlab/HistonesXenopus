
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void w_histones_standardDemeth_all(realtype *w, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *tcl) {
  w[0] = p[4]*x[1];
  w[1] = p[5]*x[2];
  w[2] = p[6]*x[3];
  w[3] = p[1]*x[4];
  w[4] = p[1]*x[5];
  w[5] = p[4]*x[5];
  w[6] = p[1]*x[6];
  w[7] = p[5]*x[6];
  w[8] = p[1]*x[7];
  w[9] = p[6]*x[7];
  w[10] = p[2]*x[8];
  w[11] = p[2]*x[9];
  w[12] = p[4]*x[9];
  w[13] = p[2]*x[10];
  w[14] = p[5]*x[10];
  w[15] = p[2]*x[11];
  w[16] = p[6]*x[11];
  w[17] = p[3]*x[12];
  w[18] = p[3]*x[13];
  w[19] = p[4]*x[13];
  w[20] = p[3]*x[14];
  w[21] = p[5]*x[14];
  w[22] = p[4]*x[16];
  w[23] = p[5]*x[17];
  w[24] = p[6]*x[18];
  w[25] = p[1]*x[19];
  w[26] = p[1]*x[20];
  w[27] = p[4]*x[20];
  w[28] = p[1]*x[21];
  w[29] = p[5]*x[21];
  w[30] = p[1]*x[22];
  w[31] = p[6]*x[22];
  w[32] = p[2]*x[23];
  w[33] = p[2]*x[24];
  w[34] = p[4]*x[24];
  w[35] = p[2]*x[25];
  w[36] = p[5]*x[25];
  w[37] = p[2]*x[26];
  w[38] = p[6]*x[26];
  w[39] = p[3]*x[27];
  w[40] = p[3]*x[28];
  w[41] = p[4]*x[28];
  w[42] = p[3]*x[29];
  w[43] = p[5]*x[29];
  w[44] = h[0]-1.0;
  w[45] = p[4]*x[31];
  w[46] = p[5]*x[32];
  w[47] = p[6]*x[33];
  w[48] = p[1]*x[34];
  w[49] = p[1]*x[35];
  w[50] = p[4]*x[35];
  w[51] = p[1]*x[36];
  w[52] = p[5]*x[36];
  w[53] = p[1]*x[37];
  w[54] = p[6]*x[37];
  w[55] = p[2]*x[38];
  w[56] = p[2]*x[39];
  w[57] = p[4]*x[39];
  w[58] = p[2]*x[40];
  w[59] = p[5]*x[40];
  w[60] = p[2]*x[41];
  w[61] = p[6]*x[41];
  w[62] = p[3]*x[42];
  w[63] = p[3]*x[43];
  w[64] = p[4]*x[43];
  w[65] = p[3]*x[44];
  w[66] = p[5]*x[44];
}

