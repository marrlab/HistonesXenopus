
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void JDiag_histones_standardDemeth_all(realtype *JDiag, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w, const realtype *dwdx) {
  JDiag[0+0*45] = -p[7]-p[8];
  JDiag[1+0*45] = -p[9]-p[10]-dwdx[0];
  JDiag[2+0*45] = -p[11]-p[12]-dwdx[1];
  JDiag[3+0*45] = -p[13]-dwdx[2];
  JDiag[4+0*45] = -p[14]-p[15]-dwdx[3];
  JDiag[5+0*45] = -p[16]-p[17]-dwdx[4]-dwdx[5];
  JDiag[6+0*45] = -p[18]-p[19]-dwdx[6]-dwdx[7];
  JDiag[7+0*45] = -p[20]-dwdx[8]-dwdx[9];
  JDiag[8+0*45] = -p[21]-p[22]-dwdx[10];
  JDiag[9+0*45] = -p[23]-p[24]-dwdx[11]-dwdx[12];
  JDiag[10+0*45] = -p[25]-p[26]-dwdx[13]-dwdx[14];
  JDiag[11+0*45] = -dwdx[15]-dwdx[16];
  JDiag[12+0*45] = -p[27]-dwdx[17];
  JDiag[13+0*45] = -p[28]-dwdx[18]-dwdx[19];
  JDiag[14+0*45] = -dwdx[20]-dwdx[21];
  JDiag[15+0*45] = -p[7]-p[8]-h[0]*p[0];
  JDiag[16+0*45] = -p[9]-p[10]-dwdx[22]-h[0]*p[0];
  JDiag[17+0*45] = -p[11]-p[12]-dwdx[23]-h[0]*p[0];
  JDiag[18+0*45] = -p[13]-dwdx[24]-h[0]*p[0];
  JDiag[19+0*45] = -p[14]-p[15]-dwdx[25]-h[0]*p[0];
  JDiag[20+0*45] = -p[16]-p[17]-dwdx[26]-dwdx[27]-h[0]*p[0];
  JDiag[21+0*45] = -p[18]-p[19]-dwdx[28]-dwdx[29]-h[0]*p[0];
  JDiag[22+0*45] = -p[20]-dwdx[30]-dwdx[31]-h[0]*p[0];
  JDiag[23+0*45] = -p[21]-p[22]-dwdx[32]-h[0]*p[0];
  JDiag[24+0*45] = -p[23]-p[24]-dwdx[33]-dwdx[34]-h[0]*p[0];
  JDiag[25+0*45] = -p[25]-p[26]-dwdx[35]-dwdx[36]-h[0]*p[0];
  JDiag[26+0*45] = -dwdx[37]-dwdx[38]-h[0]*p[0];
  JDiag[27+0*45] = -p[27]-dwdx[39]-h[0]*p[0];
  JDiag[28+0*45] = -p[28]-dwdx[40]-dwdx[41]-h[0]*p[0];
  JDiag[29+0*45] = -dwdx[42]-dwdx[43]-h[0]*p[0];
  JDiag[30+0*45] = -p[7]-p[8]+p[0]*w[44];
  JDiag[31+0*45] = -p[9]-p[10]-dwdx[44]+p[0]*w[44];
  JDiag[32+0*45] = -p[11]-p[12]-dwdx[45]+p[0]*w[44];
  JDiag[33+0*45] = -p[13]-dwdx[46]+p[0]*w[44];
  JDiag[34+0*45] = -p[14]-p[15]-dwdx[47]+p[0]*w[44];
  JDiag[35+0*45] = -p[16]-p[17]-dwdx[48]-dwdx[49]+p[0]*w[44];
  JDiag[36+0*45] = -p[18]-p[19]-dwdx[50]-dwdx[51]+p[0]*w[44];
  JDiag[37+0*45] = -p[20]-dwdx[52]-dwdx[53]+p[0]*w[44];
  JDiag[38+0*45] = -p[21]-p[22]-dwdx[54]+p[0]*w[44];
  JDiag[39+0*45] = -p[23]-p[24]-dwdx[55]-dwdx[56]+p[0]*w[44];
  JDiag[40+0*45] = -p[25]-p[26]-dwdx[57]-dwdx[58]+p[0]*w[44];
  JDiag[41+0*45] = -dwdx[59]-dwdx[60]+p[0]*w[44];
  JDiag[42+0*45] = -p[27]-dwdx[61]+p[0]*w[44];
  JDiag[43+0*45] = -p[28]-dwdx[62]-dwdx[63]+p[0]*w[44];
  JDiag[44+0*45] = -dwdx[64]-dwdx[65]+p[0]*w[44];
}

