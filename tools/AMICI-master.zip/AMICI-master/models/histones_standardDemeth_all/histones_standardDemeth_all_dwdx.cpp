
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void dwdx_histones_standardDemeth_all(realtype *dwdx, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w, const realtype *tcl) {
  dwdx[0] = p[4];
  dwdx[1] = p[5];
  dwdx[2] = p[6];
  dwdx[3] = p[1];
  dwdx[4] = p[1];
  dwdx[5] = p[4];
  dwdx[6] = p[1];
  dwdx[7] = p[5];
  dwdx[8] = p[1];
  dwdx[9] = p[6];
  dwdx[10] = p[2];
  dwdx[11] = p[2];
  dwdx[12] = p[4];
  dwdx[13] = p[2];
  dwdx[14] = p[5];
  dwdx[15] = p[2];
  dwdx[16] = p[6];
  dwdx[17] = p[3];
  dwdx[18] = p[3];
  dwdx[19] = p[4];
  dwdx[20] = p[3];
  dwdx[21] = p[5];
  dwdx[22] = p[4];
  dwdx[23] = p[5];
  dwdx[24] = p[6];
  dwdx[25] = p[1];
  dwdx[26] = p[1];
  dwdx[27] = p[4];
  dwdx[28] = p[1];
  dwdx[29] = p[5];
  dwdx[30] = p[1];
  dwdx[31] = p[6];
  dwdx[32] = p[2];
  dwdx[33] = p[2];
  dwdx[34] = p[4];
  dwdx[35] = p[2];
  dwdx[36] = p[5];
  dwdx[37] = p[2];
  dwdx[38] = p[6];
  dwdx[39] = p[3];
  dwdx[40] = p[3];
  dwdx[41] = p[4];
  dwdx[42] = p[3];
  dwdx[43] = p[5];
  dwdx[44] = p[4];
  dwdx[45] = p[5];
  dwdx[46] = p[6];
  dwdx[47] = p[1];
  dwdx[48] = p[1];
  dwdx[49] = p[4];
  dwdx[50] = p[1];
  dwdx[51] = p[5];
  dwdx[52] = p[1];
  dwdx[53] = p[6];
  dwdx[54] = p[2];
  dwdx[55] = p[2];
  dwdx[56] = p[4];
  dwdx[57] = p[2];
  dwdx[58] = p[5];
  dwdx[59] = p[2];
  dwdx[60] = p[6];
  dwdx[61] = p[3];
  dwdx[62] = p[3];
  dwdx[63] = p[4];
  dwdx[64] = p[3];
  dwdx[65] = p[5];
}

