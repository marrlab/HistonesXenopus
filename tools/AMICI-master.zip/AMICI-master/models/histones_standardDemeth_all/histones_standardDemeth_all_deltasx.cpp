
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void deltasx_histones_standardDemeth_all(double *deltasx, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w, const int ip, const int ie, const realtype *xdot, const realtype *xdot_old, const realtype *sx, const realtype *stau) {
switch (ip) {
  case 0: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 1: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 2: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 3: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 4: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 5: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 6: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 7: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 8: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 9: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 10: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 11: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 12: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 13: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 14: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 15: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 16: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 17: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 18: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 19: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 20: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 21: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 22: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 23: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 24: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 25: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 26: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 27: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

  case 28: {
              switch(ie) { 
              case 0: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              case 1: {
  deltasx[15] = -stau[0]*(xdot[15]-xdot_old[15]);
  deltasx[16] = -stau[0]*(xdot[16]-xdot_old[16]);
  deltasx[17] = -stau[0]*(xdot[17]-xdot_old[17]);
  deltasx[18] = -stau[0]*(xdot[18]-xdot_old[18]);
  deltasx[19] = -stau[0]*(xdot[19]-xdot_old[19]);
  deltasx[20] = -stau[0]*(xdot[20]-xdot_old[20]);
  deltasx[21] = -stau[0]*(xdot[21]-xdot_old[21]);
  deltasx[22] = -stau[0]*(xdot[22]-xdot_old[22]);
  deltasx[23] = -stau[0]*(xdot[23]-xdot_old[23]);
  deltasx[24] = -stau[0]*(xdot[24]-xdot_old[24]);
  deltasx[25] = -stau[0]*(xdot[25]-xdot_old[25]);
  deltasx[26] = -stau[0]*(xdot[26]-xdot_old[26]);
  deltasx[27] = -stau[0]*(xdot[27]-xdot_old[27]);
  deltasx[28] = -stau[0]*(xdot[28]-xdot_old[28]);
  deltasx[29] = -stau[0]*(xdot[29]-xdot_old[29]);
  deltasx[30] = -stau[0]*(xdot[30]-xdot_old[30]);
  deltasx[31] = -stau[0]*(xdot[31]-xdot_old[31]);
  deltasx[32] = -stau[0]*(xdot[32]-xdot_old[32]);
  deltasx[33] = -stau[0]*(xdot[33]-xdot_old[33]);
  deltasx[34] = -stau[0]*(xdot[34]-xdot_old[34]);
  deltasx[35] = -stau[0]*(xdot[35]-xdot_old[35]);
  deltasx[36] = -stau[0]*(xdot[36]-xdot_old[36]);
  deltasx[37] = -stau[0]*(xdot[37]-xdot_old[37]);
  deltasx[38] = -stau[0]*(xdot[38]-xdot_old[38]);
  deltasx[39] = -stau[0]*(xdot[39]-xdot_old[39]);
  deltasx[40] = -stau[0]*(xdot[40]-xdot_old[40]);
  deltasx[41] = -stau[0]*(xdot[41]-xdot_old[41]);
  deltasx[42] = -stau[0]*(xdot[42]-xdot_old[42]);
  deltasx[43] = -stau[0]*(xdot[43]-xdot_old[43]);
  deltasx[44] = -stau[0]*(xdot[44]-xdot_old[44]);

              } break;

              } 

  } break;

}
}

