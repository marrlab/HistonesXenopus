
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void dxdotdp_histones_standardDemeth_all(realtype *dxdotdp, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const int ip, const realtype *w, const realtype *dwdp) {
switch (ip) {
  case 0: {
  dxdotdp[15] = h[0]-h[0]*x[15];
  dxdotdp[16] = -h[0]*x[16];
  dxdotdp[17] = -h[0]*x[17];
  dxdotdp[18] = -h[0]*x[18];
  dxdotdp[19] = -h[0]*x[19];
  dxdotdp[20] = -h[0]*x[20];
  dxdotdp[21] = -h[0]*x[21];
  dxdotdp[22] = -h[0]*x[22];
  dxdotdp[23] = -h[0]*x[23];
  dxdotdp[24] = -h[0]*x[24];
  dxdotdp[25] = -h[0]*x[25];
  dxdotdp[26] = -h[0]*x[26];
  dxdotdp[27] = -h[0]*x[27];
  dxdotdp[28] = -h[0]*x[28];
  dxdotdp[29] = -h[0]*x[29];
  dxdotdp[30] = -w[44]+x[30]*w[44];
  dxdotdp[31] = x[31]*w[44];
  dxdotdp[32] = x[32]*w[44];
  dxdotdp[33] = x[33]*w[44];
  dxdotdp[34] = x[34]*w[44];
  dxdotdp[35] = x[35]*w[44];
  dxdotdp[36] = x[36]*w[44];
  dxdotdp[37] = x[37]*w[44];
  dxdotdp[38] = x[38]*w[44];
  dxdotdp[39] = x[39]*w[44];
  dxdotdp[40] = x[40]*w[44];
  dxdotdp[41] = x[41]*w[44];
  dxdotdp[42] = x[42]*w[44];
  dxdotdp[43] = w[44]*x[43];
  dxdotdp[44] = w[44]*x[44];

  } break;

  case 1: {
  dxdotdp[0] = dwdp[0];
  dxdotdp[1] = dwdp[1];
  dxdotdp[2] = dwdp[2];
  dxdotdp[3] = dwdp[3];
  dxdotdp[4] = -dwdp[0];
  dxdotdp[5] = -dwdp[1];
  dxdotdp[6] = -dwdp[2];
  dxdotdp[7] = -dwdp[3];
  dxdotdp[15] = dwdp[4];
  dxdotdp[16] = dwdp[5];
  dxdotdp[17] = dwdp[6];
  dxdotdp[18] = dwdp[7];
  dxdotdp[19] = -dwdp[4];
  dxdotdp[20] = -dwdp[5];
  dxdotdp[21] = -dwdp[6];
  dxdotdp[22] = -dwdp[7];
  dxdotdp[30] = dwdp[8];
  dxdotdp[31] = dwdp[9];
  dxdotdp[32] = dwdp[10];
  dxdotdp[33] = dwdp[11];
  dxdotdp[34] = -dwdp[8];
  dxdotdp[35] = -dwdp[9];
  dxdotdp[36] = -dwdp[10];
  dxdotdp[37] = -dwdp[11];

  } break;

  case 2: {
  dxdotdp[4] = dwdp[12];
  dxdotdp[5] = dwdp[13];
  dxdotdp[6] = dwdp[14];
  dxdotdp[7] = dwdp[15];
  dxdotdp[8] = -dwdp[12];
  dxdotdp[9] = -dwdp[13];
  dxdotdp[10] = -dwdp[14];
  dxdotdp[11] = -dwdp[15];
  dxdotdp[19] = dwdp[16];
  dxdotdp[20] = dwdp[17];
  dxdotdp[21] = dwdp[18];
  dxdotdp[22] = dwdp[19];
  dxdotdp[23] = -dwdp[16];
  dxdotdp[24] = -dwdp[17];
  dxdotdp[25] = -dwdp[18];
  dxdotdp[26] = -dwdp[19];
  dxdotdp[34] = dwdp[20];
  dxdotdp[35] = dwdp[21];
  dxdotdp[36] = dwdp[22];
  dxdotdp[37] = dwdp[23];
  dxdotdp[38] = -dwdp[20];
  dxdotdp[39] = -dwdp[21];
  dxdotdp[40] = -dwdp[22];
  dxdotdp[41] = -dwdp[23];

  } break;

  case 3: {
  dxdotdp[8] = dwdp[24];
  dxdotdp[9] = dwdp[25];
  dxdotdp[10] = dwdp[26];
  dxdotdp[12] = -dwdp[24];
  dxdotdp[13] = -dwdp[25];
  dxdotdp[14] = -dwdp[26];
  dxdotdp[23] = dwdp[27];
  dxdotdp[24] = dwdp[28];
  dxdotdp[25] = dwdp[29];
  dxdotdp[27] = -dwdp[27];
  dxdotdp[28] = -dwdp[28];
  dxdotdp[29] = -dwdp[29];
  dxdotdp[38] = dwdp[30];
  dxdotdp[39] = dwdp[31];
  dxdotdp[40] = dwdp[32];
  dxdotdp[42] = -dwdp[30];
  dxdotdp[43] = -dwdp[31];
  dxdotdp[44] = -dwdp[32];

  } break;

  case 4: {
  dxdotdp[0] = dwdp[33];
  dxdotdp[1] = -dwdp[33];
  dxdotdp[4] = dwdp[34];
  dxdotdp[5] = -dwdp[34];
  dxdotdp[8] = dwdp[35];
  dxdotdp[9] = -dwdp[35];
  dxdotdp[12] = dwdp[36];
  dxdotdp[13] = -dwdp[36];
  dxdotdp[15] = dwdp[37];
  dxdotdp[16] = -dwdp[37];
  dxdotdp[19] = dwdp[38];
  dxdotdp[20] = -dwdp[38];
  dxdotdp[23] = dwdp[39];
  dxdotdp[24] = -dwdp[39];
  dxdotdp[27] = dwdp[40];
  dxdotdp[28] = -dwdp[40];
  dxdotdp[30] = dwdp[41];
  dxdotdp[31] = -dwdp[41];
  dxdotdp[34] = dwdp[42];
  dxdotdp[35] = -dwdp[42];
  dxdotdp[38] = dwdp[43];
  dxdotdp[39] = -dwdp[43];
  dxdotdp[42] = dwdp[44];
  dxdotdp[43] = -dwdp[44];

  } break;

  case 5: {
  dxdotdp[1] = dwdp[45];
  dxdotdp[2] = -dwdp[45];
  dxdotdp[5] = dwdp[46];
  dxdotdp[6] = -dwdp[46];
  dxdotdp[9] = dwdp[47];
  dxdotdp[10] = -dwdp[47];
  dxdotdp[13] = dwdp[48];
  dxdotdp[14] = -dwdp[48];
  dxdotdp[16] = dwdp[49];
  dxdotdp[17] = -dwdp[49];
  dxdotdp[20] = dwdp[50];
  dxdotdp[21] = -dwdp[50];
  dxdotdp[24] = dwdp[51];
  dxdotdp[25] = -dwdp[51];
  dxdotdp[28] = dwdp[52];
  dxdotdp[29] = -dwdp[52];
  dxdotdp[31] = dwdp[53];
  dxdotdp[32] = -dwdp[53];
  dxdotdp[35] = dwdp[54];
  dxdotdp[36] = -dwdp[54];
  dxdotdp[39] = dwdp[55];
  dxdotdp[40] = -dwdp[55];
  dxdotdp[43] = dwdp[56];
  dxdotdp[44] = -dwdp[56];

  } break;

  case 6: {
  dxdotdp[2] = dwdp[57];
  dxdotdp[3] = -dwdp[57];
  dxdotdp[6] = dwdp[58];
  dxdotdp[7] = -dwdp[58];
  dxdotdp[10] = dwdp[59];
  dxdotdp[11] = -dwdp[59];
  dxdotdp[17] = dwdp[60];
  dxdotdp[18] = -dwdp[60];
  dxdotdp[21] = dwdp[61];
  dxdotdp[22] = -dwdp[61];
  dxdotdp[25] = dwdp[62];
  dxdotdp[26] = -dwdp[62];
  dxdotdp[32] = dwdp[63];
  dxdotdp[33] = -dwdp[63];
  dxdotdp[36] = dwdp[64];
  dxdotdp[37] = -dwdp[64];
  dxdotdp[40] = dwdp[65];
  dxdotdp[41] = -dwdp[65];

  } break;

  case 7: {
  dxdotdp[0] = -x[0];
  dxdotdp[1] = x[0];
  dxdotdp[15] = -x[15];
  dxdotdp[16] = x[15];
  dxdotdp[30] = -x[30];
  dxdotdp[31] = x[30];

  } break;

  case 8: {
  dxdotdp[0] = -x[0];
  dxdotdp[4] = x[0];
  dxdotdp[15] = -x[15];
  dxdotdp[19] = x[15];
  dxdotdp[30] = -x[30];
  dxdotdp[34] = x[30];

  } break;

  case 9: {
  dxdotdp[1] = -x[1];
  dxdotdp[2] = x[1];
  dxdotdp[16] = -x[16];
  dxdotdp[17] = x[16];
  dxdotdp[31] = -x[31];
  dxdotdp[32] = x[31];

  } break;

  case 10: {
  dxdotdp[1] = -x[1];
  dxdotdp[5] = x[1];
  dxdotdp[16] = -x[16];
  dxdotdp[20] = x[16];
  dxdotdp[31] = -x[31];
  dxdotdp[35] = x[31];

  } break;

  case 11: {
  dxdotdp[2] = -x[2];
  dxdotdp[3] = x[2];
  dxdotdp[17] = -x[17];
  dxdotdp[18] = x[17];
  dxdotdp[32] = -x[32];
  dxdotdp[33] = x[32];

  } break;

  case 12: {
  dxdotdp[2] = -x[2];
  dxdotdp[6] = x[2];
  dxdotdp[17] = -x[17];
  dxdotdp[21] = x[17];
  dxdotdp[32] = -x[32];
  dxdotdp[36] = x[32];

  } break;

  case 13: {
  dxdotdp[3] = -x[3];
  dxdotdp[7] = x[3];
  dxdotdp[18] = -x[18];
  dxdotdp[22] = x[18];
  dxdotdp[33] = -x[33];
  dxdotdp[37] = x[33];

  } break;

  case 14: {
  dxdotdp[4] = -x[4];
  dxdotdp[5] = x[4];
  dxdotdp[19] = -x[19];
  dxdotdp[20] = x[19];
  dxdotdp[34] = -x[34];
  dxdotdp[35] = x[34];

  } break;

  case 15: {
  dxdotdp[4] = -x[4];
  dxdotdp[8] = x[4];
  dxdotdp[19] = -x[19];
  dxdotdp[23] = x[19];
  dxdotdp[34] = -x[34];
  dxdotdp[38] = x[34];

  } break;

  case 16: {
  dxdotdp[5] = -x[5];
  dxdotdp[6] = x[5];
  dxdotdp[20] = -x[20];
  dxdotdp[21] = x[20];
  dxdotdp[35] = -x[35];
  dxdotdp[36] = x[35];

  } break;

  case 17: {
  dxdotdp[5] = -x[5];
  dxdotdp[9] = x[5];
  dxdotdp[20] = -x[20];
  dxdotdp[24] = x[20];
  dxdotdp[35] = -x[35];
  dxdotdp[39] = x[35];

  } break;

  case 18: {
  dxdotdp[6] = -x[6];
  dxdotdp[7] = x[6];
  dxdotdp[21] = -x[21];
  dxdotdp[22] = x[21];
  dxdotdp[36] = -x[36];
  dxdotdp[37] = x[36];

  } break;

  case 19: {
  dxdotdp[6] = -x[6];
  dxdotdp[10] = x[6];
  dxdotdp[21] = -x[21];
  dxdotdp[25] = x[21];
  dxdotdp[36] = -x[36];
  dxdotdp[40] = x[36];

  } break;

  case 20: {
  dxdotdp[7] = -x[7];
  dxdotdp[11] = x[7];
  dxdotdp[22] = -x[22];
  dxdotdp[26] = x[22];
  dxdotdp[37] = -x[37];
  dxdotdp[41] = x[37];

  } break;

  case 21: {
  dxdotdp[8] = -x[8];
  dxdotdp[9] = x[8];
  dxdotdp[23] = -x[23];
  dxdotdp[24] = x[23];
  dxdotdp[38] = -x[38];
  dxdotdp[39] = x[38];

  } break;

  case 22: {
  dxdotdp[8] = -x[8];
  dxdotdp[12] = x[8];
  dxdotdp[23] = -x[23];
  dxdotdp[27] = x[23];
  dxdotdp[38] = -x[38];
  dxdotdp[42] = x[38];

  } break;

  case 23: {
  dxdotdp[9] = -x[9];
  dxdotdp[10] = x[9];
  dxdotdp[24] = -x[24];
  dxdotdp[25] = x[24];
  dxdotdp[39] = -x[39];
  dxdotdp[40] = x[39];

  } break;

  case 24: {
  dxdotdp[9] = -x[9];
  dxdotdp[13] = x[9];
  dxdotdp[24] = -x[24];
  dxdotdp[28] = x[24];
  dxdotdp[39] = -x[39];
  dxdotdp[43] = x[39];

  } break;

  case 25: {
  dxdotdp[10] = -x[10];
  dxdotdp[11] = x[10];
  dxdotdp[25] = -x[25];
  dxdotdp[26] = x[25];
  dxdotdp[40] = -x[40];
  dxdotdp[41] = x[40];

  } break;

  case 26: {
  dxdotdp[10] = -x[10];
  dxdotdp[14] = x[10];
  dxdotdp[25] = -x[25];
  dxdotdp[29] = x[25];
  dxdotdp[40] = -x[40];
  dxdotdp[44] = x[40];

  } break;

  case 27: {
  dxdotdp[12] = -x[12];
  dxdotdp[13] = x[12];
  dxdotdp[27] = -x[27];
  dxdotdp[28] = x[27];
  dxdotdp[42] = -x[42];
  dxdotdp[43] = x[42];

  } break;

  case 28: {
  dxdotdp[13] = -x[13];
  dxdotdp[14] = x[13];
  dxdotdp[28] = -x[28];
  dxdotdp[29] = x[28];
  dxdotdp[43] = -x[43];
  dxdotdp[44] = x[43];

  } break;

}
}

