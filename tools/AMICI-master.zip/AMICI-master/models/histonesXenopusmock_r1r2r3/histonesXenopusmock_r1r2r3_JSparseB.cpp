
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
#include <sunmatrix/sunmatrix_sparse.h> //SUNMatrixContent_Sparse definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void JSparseB_histonesXenopusmock_r1r2r3(SUNMatrixContent_Sparse JSparseB, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *xB, const realtype *w, const realtype *dwdx) {
  JSparseB->indexvals[0] = 0;
  JSparseB->indexvals[1] = 1;
  JSparseB->indexvals[2] = 2;
  JSparseB->indexvals[3] = 3;
  JSparseB->indexvals[4] = 0;
  JSparseB->indexvals[5] = 1;
  JSparseB->indexvals[6] = 1;
  JSparseB->indexvals[7] = 2;
  JSparseB->indexvals[8] = 2;
  JSparseB->indexvals[9] = 3;
  JSparseB->indexptrs[0] = 0;
  JSparseB->indexptrs[1] = 4;
  JSparseB->indexptrs[2] = 6;
  JSparseB->indexptrs[3] = 8;
  JSparseB->indexptrs[4] = 10;
  JSparseB->data[0] = p[5];
  JSparseB->data[1] = w[0]*(-6.931471805599453E-1);
  JSparseB->data[2] = w[0]*(-6.931471805599453E-1);
  JSparseB->data[3] = -dwdx[0];
  JSparseB->data[4] = -p[5];
  JSparseB->data[5] = p[6]+w[1];
  JSparseB->data[6] = -p[6];
  JSparseB->data[7] = p[7]+w[1];
  JSparseB->data[8] = -p[7];
  JSparseB->data[9] = dwdx[0];
}

