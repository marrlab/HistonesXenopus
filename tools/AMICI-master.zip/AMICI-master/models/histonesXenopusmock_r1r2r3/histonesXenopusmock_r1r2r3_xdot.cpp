
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void xdot_histonesXenopusmock_r1r2r3(realtype *xdot, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w) {
  xdot[0] = w[2]-p[5]*x[0]+w[0]*x[1]*6.931471805599453E-1+w[0]*x[2]*6.931471805599453E-1;
  xdot[1] = -x[1]*(p[6]+w[1])+p[5]*x[0];
  xdot[2] = -x[2]*(p[7]+w[1])+p[6]*x[1];
  xdot[3] = -w[2]+p[7]*x[2];
}

