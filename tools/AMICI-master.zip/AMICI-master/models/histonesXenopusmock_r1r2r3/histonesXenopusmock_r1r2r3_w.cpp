
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void w_histonesXenopusmock_r1r2r3(realtype *w, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *tcl) {
  w[0] = 1.0/p[0];
  w[1] = w[0]*6.931471805599453E-1;
  w[2] = w[0]*x[3]*6.931471805599453E-1;
}

