
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void dxdotdp_histonesXenopusmock_r1r2r3(realtype *dxdotdp, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const int ip, const realtype *w, const realtype *dwdp) {
switch (ip) {
  case 0: {
  dxdotdp[0] = dwdp[2]+dwdp[0]*(x[1]*6.931471805599453E-1+x[2]*6.931471805599453E-1);
  dxdotdp[1] = -x[1]*dwdp[1];
  dxdotdp[2] = -x[2]*dwdp[1];
  dxdotdp[3] = -dwdp[2];

  } break;

  case 5: {
  dxdotdp[0] = -x[0];
  dxdotdp[1] = x[0];

  } break;

  case 6: {
  dxdotdp[1] = -x[1];
  dxdotdp[2] = x[1];

  } break;

  case 7: {
  dxdotdp[2] = -x[2];
  dxdotdp[3] = x[2];

  } break;

}
}

