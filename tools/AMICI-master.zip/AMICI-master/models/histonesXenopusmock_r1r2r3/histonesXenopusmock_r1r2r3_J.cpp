
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void J_histonesXenopusmock_r1r2r3(realtype *J, const realtype t, const realtype *x, const double *p, const double *k, const realtype *h, const realtype *w, const realtype *dwdx) {
  J[0+0*4] = -p[5];
  J[0+1*4] = w[0]*6.931471805599453E-1;
  J[0+2*4] = w[0]*6.931471805599453E-1;
  J[0+3*4] = dwdx[0];
  J[1+0*4] = p[5];
  J[1+1*4] = -p[6]-w[1];
  J[2+1*4] = p[6];
  J[2+2*4] = -p[7]-w[1];
  J[3+2*4] = p[7];
  J[3+3*4] = -dwdx[0];
}

