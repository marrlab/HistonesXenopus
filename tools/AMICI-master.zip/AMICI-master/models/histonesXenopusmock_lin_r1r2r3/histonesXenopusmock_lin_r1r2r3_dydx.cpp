
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void dydx_histonesXenopusmock_lin_r1r2r3(double *dydx, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w, const realtype *dwdx) {
  dydx[0+0*4] = -1.0/(x[0]+x[1]+x[2]+x[3])+1.0/x[0];
  dydx[0+1*4] = -1.0/(x[0]+x[1]+x[2]+x[3]);
  dydx[0+2*4] = -1.0/(x[0]+x[1]+x[2]+x[3]);
  dydx[0+3*4] = -1.0/(x[0]+x[1]+x[2]+x[3]);
  dydx[1+0*4] = -1.0/(x[0]+x[1]+x[2]+x[3]);
  dydx[1+1*4] = -1.0/(x[0]+x[1]+x[2]+x[3])+1.0/x[1];
  dydx[1+2*4] = -1.0/(x[0]+x[1]+x[2]+x[3]);
  dydx[1+3*4] = -1.0/(x[0]+x[1]+x[2]+x[3]);
  dydx[2+0*4] = -1.0/(x[0]+x[1]+x[2]+x[3]);
  dydx[2+1*4] = -1.0/(x[0]+x[1]+x[2]+x[3]);
  dydx[2+2*4] = -1.0/(x[0]+x[1]+x[2]+x[3])+1.0/x[2];
  dydx[2+3*4] = -1.0/(x[0]+x[1]+x[2]+x[3]);
  dydx[3+0*4] = -1.0/(x[0]+x[1]+x[2]+x[3]);
  dydx[3+1*4] = -1.0/(x[0]+x[1]+x[2]+x[3]);
  dydx[3+2*4] = -1.0/(x[0]+x[1]+x[2]+x[3]);
  dydx[3+3*4] = -1.0/(x[0]+x[1]+x[2]+x[3])+1.0/x[3];
}

