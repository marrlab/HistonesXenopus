#ifndef _amici_wrapfunctions_h
#define _amici_wrapfunctions_h

#include "histonesXenopusmock_lin_r1r2r3.h"

std::unique_ptr<amici::Model> getModel();

#endif /* _amici_wrapfunctions_h */
