
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void JDiag_histonesXenopusmock_lin_r1r2r3(realtype *JDiag, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w, const realtype *dwdx) {
  JDiag[0+0*4] = -p[5]-w[2]*3.465735902799726E-1+6.931471805599453E-1/w[1];
  JDiag[1+0*4] = -p[6]-w[2]*3.465735902799726E-1;
  JDiag[2+0*4] = -p[7]-w[2]*3.465735902799726E-1;
  JDiag[3+0*4] = w[2]*(-3.465735902799726E-1);
}

