
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void w_histonesXenopusmock_lin_r1r2r3(realtype *w, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *tcl) {
  w[0] = t*p[0];
  w[1] = w[0]+1.0/2.0;
  w[2] = 1.0/(w[1]*w[1]);
}

