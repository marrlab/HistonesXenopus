
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void x0_histonesXenopusmock_lin_r1r2r3(realtype *x0, const realtype t, const realtype *p, const realtype *k) {
  x0[0] = (1.0/1.0E1)/(p[1]+p[2]+p[3]+1.0/1.0E1);
  x0[1] = p[1]/(p[1]+p[2]+p[3]+1.0/1.0E1);
  x0[2] = p[2]/(p[1]+p[2]+p[3]+1.0/1.0E1);
  x0[3] = p[3]/(p[1]+p[2]+p[3]+1.0/1.0E1);
}

