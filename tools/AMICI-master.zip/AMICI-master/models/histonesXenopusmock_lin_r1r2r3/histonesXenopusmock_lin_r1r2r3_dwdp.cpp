
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void dwdp_histonesXenopusmock_lin_r1r2r3(realtype *dwdp, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w, const realtype *tcl, const realtype *stcl) {
  dwdp[0] = t;
  dwdp[1] = dwdp[0];
  dwdp[2] = 1.0/(w[1]*w[1]*w[1])*dwdp[1]*-2.0;
}

