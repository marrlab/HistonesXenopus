
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
#include <sunmatrix/sunmatrix_sparse.h> //SUNMatrixContent_Sparse definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void JSparse_histonesXenopusmock_lin_r1r2r3(SUNMatrixContent_Sparse JSparse, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w, const realtype *dwdx) {
  JSparse->indexvals[0] = 0;
  JSparse->indexvals[1] = 1;
  JSparse->indexvals[2] = 0;
  JSparse->indexvals[3] = 1;
  JSparse->indexvals[4] = 2;
  JSparse->indexvals[5] = 0;
  JSparse->indexvals[6] = 2;
  JSparse->indexvals[7] = 3;
  JSparse->indexvals[8] = 0;
  JSparse->indexvals[9] = 3;
  JSparse->indexptrs[0] = 0;
  JSparse->indexptrs[1] = 2;
  JSparse->indexptrs[2] = 5;
  JSparse->indexptrs[3] = 8;
  JSparse->indexptrs[4] = 10;
  JSparse->data[0] = -p[5]-w[2]*3.465735902799726E-1+6.931471805599453E-1/w[1];
  JSparse->data[1] = p[5];
  JSparse->data[2] = 6.931471805599453E-1/w[1];
  JSparse->data[3] = -p[6]-w[2]*3.465735902799726E-1;
  JSparse->data[4] = p[6];
  JSparse->data[5] = 6.931471805599453E-1/w[1];
  JSparse->data[6] = -p[7]-w[2]*3.465735902799726E-1;
  JSparse->data[7] = p[7];
  JSparse->data[8] = 6.931471805599453E-1/w[1];
  JSparse->data[9] = w[2]*(-3.465735902799726E-1);
}

