
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void xdot_histonesXenopusmock_lin_r1r2r3(realtype *xdot, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w) {
  xdot[0] = -p[5]*x[0]-x[0]*w[2]*3.465735902799726E-1+(x[0]*6.931471805599453E-1+x[1]*6.931471805599453E-1+x[2]*6.931471805599453E-1+x[3]*6.931471805599453E-1)/w[1];
  xdot[1] = p[5]*x[0]-p[6]*x[1]-w[2]*x[1]*3.465735902799726E-1;
  xdot[2] = p[6]*x[1]-p[7]*x[2]-w[2]*x[2]*3.465735902799726E-1;
  xdot[3] = p[7]*x[2]-w[2]*x[3]*3.465735902799726E-1;
}

