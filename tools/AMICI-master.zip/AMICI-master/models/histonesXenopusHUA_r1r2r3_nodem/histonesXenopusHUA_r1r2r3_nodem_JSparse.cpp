
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
#include <sunmatrix/sunmatrix_sparse.h> //SUNMatrixContent_Sparse definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void JSparse_histonesXenopusHUA_r1r2r3_nodem(SUNMatrixContent_Sparse JSparse, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w, const realtype *dwdx) {
  JSparse->indexvals[0] = 0;
  JSparse->indexvals[1] = 1;
  JSparse->indexvals[2] = 1;
  JSparse->indexvals[3] = 2;
  JSparse->indexvals[4] = 2;
  JSparse->indexvals[5] = 3;
  JSparse->indexptrs[0] = 0;
  JSparse->indexptrs[1] = 2;
  JSparse->indexptrs[2] = 4;
  JSparse->indexptrs[3] = 6;
  JSparse->indexptrs[4] = 6;
  JSparse->data[0] = -p[1];
  JSparse->data[1] = p[1];
  JSparse->data[2] = -p[2];
  JSparse->data[3] = p[2];
  JSparse->data[4] = -p[3];
  JSparse->data[5] = p[3];
}

