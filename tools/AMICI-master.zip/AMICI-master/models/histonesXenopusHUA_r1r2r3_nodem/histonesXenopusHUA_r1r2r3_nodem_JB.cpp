
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void JB_histonesXenopusHUA_r1r2r3_nodem(realtype *JB, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *xB, const realtype *w, const realtype *dwdx) {
  JB[0+0*4] = p[1];
  JB[0+1*4] = -p[1];
  JB[1+1*4] = p[2];
  JB[1+2*4] = -p[2];
  JB[2+2*4] = p[3];
  JB[2+3*4] = -p[3];
}

