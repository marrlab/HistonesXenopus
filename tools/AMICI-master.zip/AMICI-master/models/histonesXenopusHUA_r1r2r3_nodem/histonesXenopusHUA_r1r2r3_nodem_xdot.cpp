
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void xdot_histonesXenopusHUA_r1r2r3_nodem(realtype *xdot, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w) {
  xdot[0] = -p[1]*x[0];
  xdot[1] = p[1]*x[0]-p[2]*x[1];
  xdot[2] = p[2]*x[1]-p[3]*x[2];
  xdot[3] = p[3]*x[2];
}

