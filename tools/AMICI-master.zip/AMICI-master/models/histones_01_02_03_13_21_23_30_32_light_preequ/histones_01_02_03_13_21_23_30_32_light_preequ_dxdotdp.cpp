
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void dxdotdp_histones_01_02_03_13_21_23_30_32_light_preequ(realtype *dxdotdp, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const int ip, const realtype *w, const realtype *dwdp) {
switch (ip) {
  case 0: {
  dxdotdp[0] = -x[0];
  dxdotdp[1] = -x[1];
  dxdotdp[2] = -x[2];
  dxdotdp[3] = -x[3];
  dxdotdp[4] = -x[4];
  dxdotdp[5] = -x[5];
  dxdotdp[7] = -x[7];
  dxdotdp[8] = x[0];
  dxdotdp[9] = x[1];
  dxdotdp[10] = x[2];
  dxdotdp[11] = x[3];
  dxdotdp[12] = x[4];
  dxdotdp[13] = x[5];
  dxdotdp[14] = x[7];

  } break;

  case 1: {
  dxdotdp[3] = -x[3];
  dxdotdp[4] = -x[4];
  dxdotdp[5] = -x[5];
  dxdotdp[6] = -x[6];
  dxdotdp[7] = -x[7];
  dxdotdp[23] = x[3];
  dxdotdp[24] = x[4];
  dxdotdp[25] = x[5];
  dxdotdp[26] = x[6];
  dxdotdp[27] = x[7];

  } break;

  case 2: {
  dxdotdp[9] = -x[9];
  dxdotdp[10] = -x[10];
  dxdotdp[11] = -x[11];
  dxdotdp[13] = -x[13];
  dxdotdp[14] = -x[14];
  dxdotdp[15] = x[9];
  dxdotdp[16] = x[10];
  dxdotdp[17] = x[11];
  dxdotdp[18] = x[13];
  dxdotdp[19] = x[14];

  } break;

  case 3: {
  dxdotdp[11] = -x[11];
  dxdotdp[12] = -x[12];
  dxdotdp[13] = -x[13];
  dxdotdp[14] = -x[14];
  dxdotdp[28] = x[11];
  dxdotdp[29] = x[12];
  dxdotdp[30] = x[13];
  dxdotdp[31] = x[14];

  } break;

  case 4: {
  dxdotdp[16] = -x[16];
  dxdotdp[17] = -x[17];
  dxdotdp[18] = -x[18];
  dxdotdp[20] = x[16];
  dxdotdp[21] = x[17];
  dxdotdp[22] = x[18];

  } break;

  case 5: {
  dxdotdp[17] = -x[17];
  dxdotdp[18] = -x[18];
  dxdotdp[19] = -x[19];
  dxdotdp[32] = x[17];
  dxdotdp[33] = x[18];
  dxdotdp[34] = x[19];

  } break;

  case 6: {
  dxdotdp[21] = -x[21];
  dxdotdp[22] = -x[22];
  dxdotdp[35] = x[21];
  dxdotdp[36] = x[22];

  } break;

  case 7: {
  dxdotdp[23] = -x[23];
  dxdotdp[24] = -x[24];
  dxdotdp[25] = -x[25];
  dxdotdp[27] = -x[27];
  dxdotdp[28] = x[23];
  dxdotdp[29] = x[24];
  dxdotdp[30] = x[25];
  dxdotdp[31] = x[27];

  } break;

  case 8: {
  dxdotdp[24] = -x[24];
  dxdotdp[25] = -x[25];
  dxdotdp[26] = -x[26];
  dxdotdp[27] = -x[27];
  dxdotdp[37] = x[24];
  dxdotdp[38] = x[25];
  dxdotdp[39] = x[26];
  dxdotdp[40] = x[27];

  } break;

  case 9: {
  dxdotdp[28] = -x[28];
  dxdotdp[30] = -x[30];
  dxdotdp[31] = -x[31];
  dxdotdp[32] = x[28];
  dxdotdp[33] = x[30];
  dxdotdp[34] = x[31];

  } break;

  case 10: {
  dxdotdp[29] = -x[29];
  dxdotdp[30] = -x[30];
  dxdotdp[31] = -x[31];
  dxdotdp[41] = x[29];
  dxdotdp[42] = x[30];
  dxdotdp[43] = x[31];

  } break;

  case 11: {
  dxdotdp[32] = -x[32];
  dxdotdp[33] = -x[33];
  dxdotdp[35] = x[32];
  dxdotdp[36] = x[33];

  } break;

  case 12: {
  dxdotdp[33] = -x[33];
  dxdotdp[34] = -x[34];
  dxdotdp[44] = x[33];
  dxdotdp[45] = x[34];

  } break;

  case 13: {
  dxdotdp[36] = -x[36];
  dxdotdp[46] = x[36];

  } break;

  case 14: {
  dxdotdp[37] = -x[37];
  dxdotdp[38] = -x[38];
  dxdotdp[40] = -x[40];
  dxdotdp[41] = x[37];
  dxdotdp[42] = x[38];
  dxdotdp[43] = x[40];

  } break;

  case 15: {
  dxdotdp[39] = -x[39];
  dxdotdp[40] = -x[40];
  dxdotdp[47] = x[39];
  dxdotdp[48] = x[40];

  } break;

  case 16: {
  dxdotdp[42] = -x[42];
  dxdotdp[43] = -x[43];
  dxdotdp[44] = x[42];
  dxdotdp[45] = x[43];

  } break;

  case 17: {
  dxdotdp[43] = -x[43];
  dxdotdp[49] = x[43];

  } break;

  case 18: {
  dxdotdp[44] = -x[44];
  dxdotdp[46] = x[44];

  } break;

  case 19: {
  dxdotdp[45] = -x[45];
  dxdotdp[50] = x[45];

  } break;

  case 20: {
  dxdotdp[48] = -x[48];
  dxdotdp[49] = x[48];

  } break;

  case 21: {
  dxdotdp[49] = -x[49];
  dxdotdp[50] = x[49];

  } break;

  case 22: {
  dxdotdp[0] = -x[0]+1.0;
  dxdotdp[1] = -x[1]+1.0;
  dxdotdp[2] = -x[2]+1.0;
  dxdotdp[3] = -x[3]+1.0;
  dxdotdp[4] = -x[4]+1.0;
  dxdotdp[5] = -x[5]+1.0;
  dxdotdp[6] = -x[6]+1.0;
  dxdotdp[7] = -x[7]+1.0;
  dxdotdp[8] = -x[8];
  dxdotdp[9] = -x[9];
  dxdotdp[10] = -x[10];
  dxdotdp[11] = -x[11];
  dxdotdp[12] = -x[12];
  dxdotdp[13] = -x[13];
  dxdotdp[14] = -x[14];
  dxdotdp[15] = -x[15];
  dxdotdp[16] = -x[16];
  dxdotdp[17] = -x[17];
  dxdotdp[18] = -x[18];
  dxdotdp[19] = -x[19];
  dxdotdp[20] = -x[20];
  dxdotdp[21] = -x[21];
  dxdotdp[22] = -x[22];
  dxdotdp[23] = -x[23];
  dxdotdp[24] = -x[24];
  dxdotdp[25] = -x[25];
  dxdotdp[26] = -x[26];
  dxdotdp[27] = -x[27];
  dxdotdp[28] = -x[28];
  dxdotdp[29] = -x[29];
  dxdotdp[30] = -x[30];
  dxdotdp[31] = -x[31];
  dxdotdp[32] = -x[32];
  dxdotdp[33] = -x[33];
  dxdotdp[34] = -x[34];
  dxdotdp[35] = -x[35];
  dxdotdp[36] = -x[36];
  dxdotdp[37] = -x[37];
  dxdotdp[38] = -x[38];
  dxdotdp[39] = -x[39];
  dxdotdp[40] = -x[40];
  dxdotdp[41] = -x[41];
  dxdotdp[42] = -x[42];
  dxdotdp[43] = -x[43];
  dxdotdp[44] = -x[44];
  dxdotdp[45] = -x[45];
  dxdotdp[46] = -x[46];
  dxdotdp[47] = -x[47];
  dxdotdp[48] = -x[48];
  dxdotdp[49] = -x[49];
  dxdotdp[50] = -x[50];

  } break;

}
}

