#ifndef _amici_wrapfunctions_h
#define _amici_wrapfunctions_h

#include "histones_01_02_03_13_21_23_30_32_light_preequ.h"

std::unique_ptr<amici::Model> getModel();

#endif /* _amici_wrapfunctions_h */
