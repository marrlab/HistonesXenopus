
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void dxdotdp_histones_01_02_03_13_21_23_30_32_all(realtype *dxdotdp, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const int ip, const realtype *w, const realtype *dwdp) {
switch (ip) {
  case 0: {
  dxdotdp[0] = -x[0];
  dxdotdp[1] = -x[1];
  dxdotdp[2] = -x[2];
  dxdotdp[3] = -x[3];
  dxdotdp[4] = -x[4];
  dxdotdp[5] = -x[5];
  dxdotdp[7] = -x[7];
  dxdotdp[8] = x[0];
  dxdotdp[9] = x[1];
  dxdotdp[10] = x[2];
  dxdotdp[11] = x[3];
  dxdotdp[12] = x[4];
  dxdotdp[13] = x[5];
  dxdotdp[14] = x[7];
  dxdotdp[51] = -x[51];
  dxdotdp[52] = -x[52];
  dxdotdp[53] = -x[53];
  dxdotdp[54] = -x[54];
  dxdotdp[55] = -x[55];
  dxdotdp[56] = -x[56];
  dxdotdp[58] = -x[58];
  dxdotdp[59] = x[51];
  dxdotdp[60] = x[52];
  dxdotdp[61] = x[53];
  dxdotdp[62] = x[54];
  dxdotdp[63] = x[55];
  dxdotdp[64] = x[56];
  dxdotdp[65] = x[58];
  dxdotdp[102] = -x[102];
  dxdotdp[103] = -x[103];
  dxdotdp[104] = -x[104];
  dxdotdp[105] = -x[105];
  dxdotdp[106] = -x[106];
  dxdotdp[107] = -x[107];
  dxdotdp[109] = -x[109];
  dxdotdp[110] = x[102];
  dxdotdp[111] = x[103];
  dxdotdp[112] = x[104];
  dxdotdp[113] = x[105];
  dxdotdp[114] = x[106];
  dxdotdp[115] = x[107];
  dxdotdp[116] = x[109];

  } break;

  case 1: {
  dxdotdp[3] = -x[3];
  dxdotdp[4] = -x[4];
  dxdotdp[5] = -x[5];
  dxdotdp[6] = -x[6];
  dxdotdp[7] = -x[7];
  dxdotdp[23] = x[3];
  dxdotdp[24] = x[4];
  dxdotdp[25] = x[5];
  dxdotdp[26] = x[6];
  dxdotdp[27] = x[7];
  dxdotdp[54] = -x[54];
  dxdotdp[55] = -x[55];
  dxdotdp[56] = -x[56];
  dxdotdp[57] = -x[57];
  dxdotdp[58] = -x[58];
  dxdotdp[74] = x[54];
  dxdotdp[75] = x[55];
  dxdotdp[76] = x[56];
  dxdotdp[77] = x[57];
  dxdotdp[78] = x[58];
  dxdotdp[105] = -x[105];
  dxdotdp[106] = -x[106];
  dxdotdp[107] = -x[107];
  dxdotdp[108] = -x[108];
  dxdotdp[109] = -x[109];
  dxdotdp[125] = x[105];
  dxdotdp[126] = x[106];
  dxdotdp[127] = x[107];
  dxdotdp[128] = x[108];
  dxdotdp[129] = x[109];

  } break;

  case 2: {
  dxdotdp[9] = -x[9];
  dxdotdp[10] = -x[10];
  dxdotdp[11] = -x[11];
  dxdotdp[13] = -x[13];
  dxdotdp[14] = -x[14];
  dxdotdp[15] = x[9];
  dxdotdp[16] = x[10];
  dxdotdp[17] = x[11];
  dxdotdp[18] = x[13];
  dxdotdp[19] = x[14];
  dxdotdp[60] = -x[60];
  dxdotdp[61] = -x[61];
  dxdotdp[62] = -x[62];
  dxdotdp[64] = -x[64];
  dxdotdp[65] = -x[65];
  dxdotdp[66] = x[60];
  dxdotdp[67] = x[61];
  dxdotdp[68] = x[62];
  dxdotdp[69] = x[64];
  dxdotdp[70] = x[65];
  dxdotdp[111] = -x[111];
  dxdotdp[112] = -x[112];
  dxdotdp[113] = -x[113];
  dxdotdp[115] = -x[115];
  dxdotdp[116] = -x[116];
  dxdotdp[117] = x[111];
  dxdotdp[118] = x[112];
  dxdotdp[119] = x[113];
  dxdotdp[120] = x[115];
  dxdotdp[121] = x[116];

  } break;

  case 3: {
  dxdotdp[11] = -x[11];
  dxdotdp[12] = -x[12];
  dxdotdp[13] = -x[13];
  dxdotdp[14] = -x[14];
  dxdotdp[28] = x[11];
  dxdotdp[29] = x[12];
  dxdotdp[30] = x[13];
  dxdotdp[31] = x[14];
  dxdotdp[62] = -x[62];
  dxdotdp[63] = -x[63];
  dxdotdp[64] = -x[64];
  dxdotdp[65] = -x[65];
  dxdotdp[79] = x[62];
  dxdotdp[80] = x[63];
  dxdotdp[81] = x[64];
  dxdotdp[82] = x[65];
  dxdotdp[113] = -x[113];
  dxdotdp[114] = -x[114];
  dxdotdp[115] = -x[115];
  dxdotdp[116] = -x[116];
  dxdotdp[130] = x[113];
  dxdotdp[131] = x[114];
  dxdotdp[132] = x[115];
  dxdotdp[133] = x[116];

  } break;

  case 4: {
  dxdotdp[16] = -x[16];
  dxdotdp[17] = -x[17];
  dxdotdp[18] = -x[18];
  dxdotdp[20] = x[16];
  dxdotdp[21] = x[17];
  dxdotdp[22] = x[18];
  dxdotdp[67] = -x[67];
  dxdotdp[68] = -x[68];
  dxdotdp[69] = -x[69];
  dxdotdp[71] = x[67];
  dxdotdp[72] = x[68];
  dxdotdp[73] = x[69];
  dxdotdp[118] = -x[118];
  dxdotdp[119] = -x[119];
  dxdotdp[120] = -x[120];
  dxdotdp[122] = x[118];
  dxdotdp[123] = x[119];
  dxdotdp[124] = x[120];

  } break;

  case 5: {
  dxdotdp[17] = -x[17];
  dxdotdp[18] = -x[18];
  dxdotdp[19] = -x[19];
  dxdotdp[32] = x[17];
  dxdotdp[33] = x[18];
  dxdotdp[34] = x[19];
  dxdotdp[68] = -x[68];
  dxdotdp[69] = -x[69];
  dxdotdp[70] = -x[70];
  dxdotdp[83] = x[68];
  dxdotdp[84] = x[69];
  dxdotdp[85] = x[70];
  dxdotdp[119] = -x[119];
  dxdotdp[120] = -x[120];
  dxdotdp[121] = -x[121];
  dxdotdp[134] = x[119];
  dxdotdp[135] = x[120];
  dxdotdp[136] = x[121];

  } break;

  case 6: {
  dxdotdp[21] = -x[21];
  dxdotdp[22] = -x[22];
  dxdotdp[35] = x[21];
  dxdotdp[36] = x[22];
  dxdotdp[72] = -x[72];
  dxdotdp[73] = -x[73];
  dxdotdp[86] = x[72];
  dxdotdp[87] = x[73];
  dxdotdp[123] = -x[123];
  dxdotdp[124] = -x[124];
  dxdotdp[137] = x[123];
  dxdotdp[138] = x[124];

  } break;

  case 7: {
  dxdotdp[23] = -x[23];
  dxdotdp[24] = -x[24];
  dxdotdp[25] = -x[25];
  dxdotdp[27] = -x[27];
  dxdotdp[28] = x[23];
  dxdotdp[29] = x[24];
  dxdotdp[30] = x[25];
  dxdotdp[31] = x[27];
  dxdotdp[74] = -x[74];
  dxdotdp[75] = -x[75];
  dxdotdp[76] = -x[76];
  dxdotdp[78] = -x[78];
  dxdotdp[79] = x[74];
  dxdotdp[80] = x[75];
  dxdotdp[81] = x[76];
  dxdotdp[82] = x[78];
  dxdotdp[125] = -x[125];
  dxdotdp[126] = -x[126];
  dxdotdp[127] = -x[127];
  dxdotdp[129] = -x[129];
  dxdotdp[130] = x[125];
  dxdotdp[131] = x[126];
  dxdotdp[132] = x[127];
  dxdotdp[133] = x[129];

  } break;

  case 8: {
  dxdotdp[24] = -x[24];
  dxdotdp[25] = -x[25];
  dxdotdp[26] = -x[26];
  dxdotdp[27] = -x[27];
  dxdotdp[37] = x[24];
  dxdotdp[38] = x[25];
  dxdotdp[39] = x[26];
  dxdotdp[40] = x[27];
  dxdotdp[75] = -x[75];
  dxdotdp[76] = -x[76];
  dxdotdp[77] = -x[77];
  dxdotdp[78] = -x[78];
  dxdotdp[88] = x[75];
  dxdotdp[89] = x[76];
  dxdotdp[90] = x[77];
  dxdotdp[91] = x[78];
  dxdotdp[126] = -x[126];
  dxdotdp[127] = -x[127];
  dxdotdp[128] = -x[128];
  dxdotdp[129] = -x[129];
  dxdotdp[139] = x[126];
  dxdotdp[140] = x[127];
  dxdotdp[141] = x[128];
  dxdotdp[142] = x[129];

  } break;

  case 9: {
  dxdotdp[28] = -x[28];
  dxdotdp[30] = -x[30];
  dxdotdp[31] = -x[31];
  dxdotdp[32] = x[28];
  dxdotdp[33] = x[30];
  dxdotdp[34] = x[31];
  dxdotdp[79] = -x[79];
  dxdotdp[81] = -x[81];
  dxdotdp[82] = -x[82];
  dxdotdp[83] = x[79];
  dxdotdp[84] = x[81];
  dxdotdp[85] = x[82];
  dxdotdp[130] = -x[130];
  dxdotdp[132] = -x[132];
  dxdotdp[133] = -x[133];
  dxdotdp[134] = x[130];
  dxdotdp[135] = x[132];
  dxdotdp[136] = x[133];

  } break;

  case 10: {
  dxdotdp[29] = -x[29];
  dxdotdp[30] = -x[30];
  dxdotdp[31] = -x[31];
  dxdotdp[41] = x[29];
  dxdotdp[42] = x[30];
  dxdotdp[43] = x[31];
  dxdotdp[80] = -x[80];
  dxdotdp[81] = -x[81];
  dxdotdp[82] = -x[82];
  dxdotdp[92] = x[80];
  dxdotdp[93] = x[81];
  dxdotdp[94] = x[82];
  dxdotdp[131] = -x[131];
  dxdotdp[132] = -x[132];
  dxdotdp[133] = -x[133];
  dxdotdp[143] = x[131];
  dxdotdp[144] = x[132];
  dxdotdp[145] = x[133];

  } break;

  case 11: {
  dxdotdp[32] = -x[32];
  dxdotdp[33] = -x[33];
  dxdotdp[35] = x[32];
  dxdotdp[36] = x[33];
  dxdotdp[83] = -x[83];
  dxdotdp[84] = -x[84];
  dxdotdp[86] = x[83];
  dxdotdp[87] = x[84];
  dxdotdp[134] = -x[134];
  dxdotdp[135] = -x[135];
  dxdotdp[137] = x[134];
  dxdotdp[138] = x[135];

  } break;

  case 12: {
  dxdotdp[33] = -x[33];
  dxdotdp[34] = -x[34];
  dxdotdp[44] = x[33];
  dxdotdp[45] = x[34];
  dxdotdp[84] = -x[84];
  dxdotdp[85] = -x[85];
  dxdotdp[95] = x[84];
  dxdotdp[96] = x[85];
  dxdotdp[135] = -x[135];
  dxdotdp[136] = -x[136];
  dxdotdp[146] = x[135];
  dxdotdp[147] = x[136];

  } break;

  case 13: {
  dxdotdp[36] = -x[36];
  dxdotdp[46] = x[36];
  dxdotdp[87] = -x[87];
  dxdotdp[97] = x[87];
  dxdotdp[138] = -x[138];
  dxdotdp[148] = x[138];

  } break;

  case 14: {
  dxdotdp[37] = -x[37];
  dxdotdp[38] = -x[38];
  dxdotdp[40] = -x[40];
  dxdotdp[41] = x[37];
  dxdotdp[42] = x[38];
  dxdotdp[43] = x[40];
  dxdotdp[88] = -x[88];
  dxdotdp[89] = -x[89];
  dxdotdp[91] = -x[91];
  dxdotdp[92] = x[88];
  dxdotdp[93] = x[89];
  dxdotdp[94] = x[91];
  dxdotdp[139] = -x[139];
  dxdotdp[140] = -x[140];
  dxdotdp[142] = -x[142];
  dxdotdp[143] = x[139];
  dxdotdp[144] = x[140];
  dxdotdp[145] = x[142];

  } break;

  case 15: {
  dxdotdp[39] = -x[39];
  dxdotdp[40] = -x[40];
  dxdotdp[47] = x[39];
  dxdotdp[48] = x[40];
  dxdotdp[90] = -x[90];
  dxdotdp[91] = -x[91];
  dxdotdp[98] = x[90];
  dxdotdp[99] = x[91];
  dxdotdp[141] = -x[141];
  dxdotdp[142] = -x[142];
  dxdotdp[149] = x[141];
  dxdotdp[150] = x[142];

  } break;

  case 16: {
  dxdotdp[42] = -x[42];
  dxdotdp[43] = -x[43];
  dxdotdp[44] = x[42];
  dxdotdp[45] = x[43];
  dxdotdp[93] = -x[93];
  dxdotdp[94] = -x[94];
  dxdotdp[95] = x[93];
  dxdotdp[96] = x[94];
  dxdotdp[144] = -x[144];
  dxdotdp[145] = -x[145];
  dxdotdp[146] = x[144];
  dxdotdp[147] = x[145];

  } break;

  case 17: {
  dxdotdp[43] = -x[43];
  dxdotdp[49] = x[43];
  dxdotdp[94] = -x[94];
  dxdotdp[100] = x[94];
  dxdotdp[145] = -x[145];
  dxdotdp[151] = x[145];

  } break;

  case 18: {
  dxdotdp[44] = -x[44];
  dxdotdp[46] = x[44];
  dxdotdp[95] = -x[95];
  dxdotdp[97] = x[95];
  dxdotdp[146] = -x[146];
  dxdotdp[148] = x[146];

  } break;

  case 19: {
  dxdotdp[45] = -x[45];
  dxdotdp[50] = x[45];
  dxdotdp[96] = -x[96];
  dxdotdp[101] = x[96];
  dxdotdp[147] = -x[147];
  dxdotdp[152] = x[147];

  } break;

  case 20: {
  dxdotdp[48] = -x[48];
  dxdotdp[49] = x[48];
  dxdotdp[99] = -x[99];
  dxdotdp[100] = x[99];
  dxdotdp[150] = -x[150];
  dxdotdp[151] = x[150];

  } break;

  case 21: {
  dxdotdp[49] = -x[49];
  dxdotdp[50] = x[49];
  dxdotdp[100] = -x[100];
  dxdotdp[101] = x[100];
  dxdotdp[151] = -x[151];
  dxdotdp[152] = x[151];

  } break;

  case 22: {
  dxdotdp[51] = dwdp[0]-h[0]*x[51];
  dxdotdp[52] = dwdp[0]-h[0]*x[52];
  dxdotdp[53] = dwdp[0]-h[0]*x[53];
  dxdotdp[54] = dwdp[0]-h[0]*x[54];
  dxdotdp[55] = dwdp[0]-h[0]*x[55];
  dxdotdp[56] = dwdp[0]-h[0]*x[56];
  dxdotdp[57] = dwdp[0]-h[0]*x[57];
  dxdotdp[58] = dwdp[0]-h[0]*x[58];
  dxdotdp[59] = -h[0]*x[59];
  dxdotdp[60] = -h[0]*x[60];
  dxdotdp[61] = -h[0]*x[61];
  dxdotdp[62] = -h[0]*x[62];
  dxdotdp[63] = -h[0]*x[63];
  dxdotdp[64] = -h[0]*x[64];
  dxdotdp[65] = -h[0]*x[65];
  dxdotdp[66] = -h[0]*x[66];
  dxdotdp[67] = -h[0]*x[67];
  dxdotdp[68] = -h[0]*x[68];
  dxdotdp[69] = -h[0]*x[69];
  dxdotdp[70] = -h[0]*x[70];
  dxdotdp[71] = -h[0]*x[71];
  dxdotdp[72] = -h[0]*x[72];
  dxdotdp[73] = -h[0]*x[73];
  dxdotdp[74] = -h[0]*x[74];
  dxdotdp[75] = -h[0]*x[75];
  dxdotdp[76] = -h[0]*x[76];
  dxdotdp[77] = -h[0]*x[77];
  dxdotdp[78] = -h[0]*x[78];
  dxdotdp[79] = -h[0]*x[79];
  dxdotdp[80] = -h[0]*x[80];
  dxdotdp[81] = -h[0]*x[81];
  dxdotdp[82] = -h[0]*x[82];
  dxdotdp[83] = -h[0]*x[83];
  dxdotdp[84] = -h[0]*x[84];
  dxdotdp[85] = -h[0]*x[85];
  dxdotdp[86] = -h[0]*x[86];
  dxdotdp[87] = -h[0]*x[87];
  dxdotdp[88] = -h[0]*x[88];
  dxdotdp[89] = -h[0]*x[89];
  dxdotdp[90] = -h[0]*x[90];
  dxdotdp[91] = -h[0]*x[91];
  dxdotdp[92] = -h[0]*x[92];
  dxdotdp[93] = -h[0]*x[93];
  dxdotdp[94] = -h[0]*x[94];
  dxdotdp[95] = -h[0]*x[95];
  dxdotdp[96] = -h[0]*x[96];
  dxdotdp[97] = -h[0]*x[97];
  dxdotdp[98] = -h[0]*x[98];
  dxdotdp[99] = -h[0]*x[99];
  dxdotdp[100] = -h[0]*x[100];
  dxdotdp[101] = -h[0]*x[101];
  dxdotdp[102] = -w[1]+w[1]*x[102];
  dxdotdp[103] = -w[1]+w[1]*x[103];
  dxdotdp[104] = -w[1]+w[1]*x[104];
  dxdotdp[105] = -w[1]+w[1]*x[105];
  dxdotdp[106] = -w[1]+w[1]*x[106];
  dxdotdp[107] = -w[1]+w[1]*x[107];
  dxdotdp[108] = -w[1]+w[1]*x[108];
  dxdotdp[109] = -w[1]+w[1]*x[109];
  dxdotdp[110] = w[1]*x[110];
  dxdotdp[111] = w[1]*x[111];
  dxdotdp[112] = w[1]*x[112];
  dxdotdp[113] = w[1]*x[113];
  dxdotdp[114] = w[1]*x[114];
  dxdotdp[115] = w[1]*x[115];
  dxdotdp[116] = w[1]*x[116];
  dxdotdp[117] = w[1]*x[117];
  dxdotdp[118] = w[1]*x[118];
  dxdotdp[119] = w[1]*x[119];
  dxdotdp[120] = w[1]*x[120];
  dxdotdp[121] = w[1]*x[121];
  dxdotdp[122] = w[1]*x[122];
  dxdotdp[123] = w[1]*x[123];
  dxdotdp[124] = w[1]*x[124];
  dxdotdp[125] = w[1]*x[125];
  dxdotdp[126] = w[1]*x[126];
  dxdotdp[127] = w[1]*x[127];
  dxdotdp[128] = w[1]*x[128];
  dxdotdp[129] = w[1]*x[129];
  dxdotdp[130] = w[1]*x[130];
  dxdotdp[131] = w[1]*x[131];
  dxdotdp[132] = w[1]*x[132];
  dxdotdp[133] = w[1]*x[133];
  dxdotdp[134] = w[1]*x[134];
  dxdotdp[135] = w[1]*x[135];
  dxdotdp[136] = w[1]*x[136];
  dxdotdp[137] = w[1]*x[137];
  dxdotdp[138] = w[1]*x[138];
  dxdotdp[139] = w[1]*x[139];
  dxdotdp[140] = w[1]*x[140];
  dxdotdp[141] = w[1]*x[141];
  dxdotdp[142] = w[1]*x[142];
  dxdotdp[143] = w[1]*x[143];
  dxdotdp[144] = w[1]*x[144];
  dxdotdp[145] = w[1]*x[145];
  dxdotdp[146] = w[1]*x[146];
  dxdotdp[147] = w[1]*x[147];
  dxdotdp[148] = w[1]*x[148];
  dxdotdp[149] = w[1]*x[149];
  dxdotdp[150] = w[1]*x[150];
  dxdotdp[151] = w[1]*x[151];
  dxdotdp[152] = w[1]*x[152];

  } break;

}
}

