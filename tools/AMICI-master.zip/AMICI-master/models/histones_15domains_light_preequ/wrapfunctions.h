#ifndef _amici_wrapfunctions_h
#define _amici_wrapfunctions_h

#include "histones_15domains_light_preequ.h"

std::unique_ptr<amici::Model> getModel();

#endif /* _amici_wrapfunctions_h */
