
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void JDiag_histones_15domains_light_preequ(realtype *JDiag, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w, const realtype *dwdx) {
  JDiag[0+0*84] = -p[22];
  JDiag[1+0*84] = -p[0]-p[22];
  JDiag[2+0*84] = -p[0]-p[22];
  JDiag[3+0*84] = -p[0]-p[22];
  JDiag[4+0*84] = -p[1]-p[22];
  JDiag[5+0*84] = -p[0]-p[1]-p[22];
  JDiag[6+0*84] = -p[0]-p[1]-p[22];
  JDiag[7+0*84] = -p[0]-p[1]-p[22];
  JDiag[8+0*84] = -p[1]-p[22];
  JDiag[9+0*84] = -p[0]-p[1]-p[22];
  JDiag[10+0*84] = -p[0]-p[1]-p[22];
  JDiag[11+0*84] = -p[0]-p[1]-p[22];
  JDiag[12+0*84] = -p[1]-p[22];
  JDiag[13+0*84] = -p[0]-p[1]-p[22];
  JDiag[14+0*84] = -p[0]-p[1]-p[22];
  JDiag[15+0*84] = -p[22];
  JDiag[16+0*84] = -p[2]-p[22];
  JDiag[17+0*84] = -p[2]-p[22];
  JDiag[18+0*84] = -p[3]-p[22];
  JDiag[19+0*84] = -p[2]-p[3]-p[22];
  JDiag[20+0*84] = -p[2]-p[3]-p[22];
  JDiag[21+0*84] = -p[3]-p[22];
  JDiag[22+0*84] = -p[2]-p[3]-p[22];
  JDiag[23+0*84] = -p[2]-p[3]-p[22];
  JDiag[24+0*84] = -p[3]-p[22];
  JDiag[25+0*84] = -p[2]-p[3]-p[22];
  JDiag[26+0*84] = -p[22];
  JDiag[27+0*84] = -p[4]-p[22];
  JDiag[28+0*84] = -p[5]-p[22];
  JDiag[29+0*84] = -p[4]-p[5]-p[22];
  JDiag[30+0*84] = -p[5]-p[22];
  JDiag[31+0*84] = -p[4]-p[5]-p[22];
  JDiag[32+0*84] = -p[5]-p[22];
  JDiag[33+0*84] = -p[22];
  JDiag[34+0*84] = -p[6]-p[22];
  JDiag[35+0*84] = -p[6]-p[22];
  JDiag[36+0*84] = -p[22];
  JDiag[37+0*84] = -p[7]-p[22];
  JDiag[38+0*84] = -p[7]-p[22];
  JDiag[39+0*84] = -p[7]-p[22];
  JDiag[40+0*84] = -p[8]-p[22];
  JDiag[41+0*84] = -p[7]-p[8]-p[22];
  JDiag[42+0*84] = -p[7]-p[8]-p[22];
  JDiag[43+0*84] = -p[7]-p[8]-p[22];
  JDiag[44+0*84] = -p[8]-p[22];
  JDiag[45+0*84] = -p[7]-p[8]-p[22];
  JDiag[46+0*84] = -p[7]-p[8]-p[22];
  JDiag[47+0*84] = -p[22];
  JDiag[48+0*84] = -p[9]-p[22];
  JDiag[49+0*84] = -p[9]-p[22];
  JDiag[50+0*84] = -p[10]-p[22];
  JDiag[51+0*84] = -p[9]-p[10]-p[22];
  JDiag[52+0*84] = -p[9]-p[10]-p[22];
  JDiag[53+0*84] = -p[10]-p[22];
  JDiag[54+0*84] = -p[9]-p[10]-p[22];
  JDiag[55+0*84] = -p[22];
  JDiag[56+0*84] = -p[11]-p[22];
  JDiag[57+0*84] = -p[12]-p[22];
  JDiag[58+0*84] = -p[11]-p[12]-p[22];
  JDiag[59+0*84] = -p[12]-p[22];
  JDiag[60+0*84] = -p[22];
  JDiag[61+0*84] = -p[13]-p[22];
  JDiag[62+0*84] = -p[22];
  JDiag[63+0*84] = -p[14]-p[22];
  JDiag[64+0*84] = -p[14]-p[22];
  JDiag[65+0*84] = -p[14]-p[22];
  JDiag[66+0*84] = -p[15]-p[22];
  JDiag[67+0*84] = -p[14]-p[15]-p[22];
  JDiag[68+0*84] = -p[14]-p[15]-p[22];
  JDiag[69+0*84] = -p[22];
  JDiag[70+0*84] = -p[16]-p[22];
  JDiag[71+0*84] = -p[16]-p[22];
  JDiag[72+0*84] = -p[17]-p[22];
  JDiag[73+0*84] = -p[16]-p[17]-p[22];
  JDiag[74+0*84] = -p[22];
  JDiag[75+0*84] = -p[18]-p[22];
  JDiag[76+0*84] = -p[19]-p[22];
  JDiag[77+0*84] = -p[22];
  JDiag[78+0*84] = -p[22];
  JDiag[79+0*84] = -p[20]-p[22];
  JDiag[80+0*84] = -p[20]-p[22];
  JDiag[81+0*84] = -p[22];
  JDiag[82+0*84] = -p[21]-p[22];
  JDiag[83+0*84] = -p[22];
}

