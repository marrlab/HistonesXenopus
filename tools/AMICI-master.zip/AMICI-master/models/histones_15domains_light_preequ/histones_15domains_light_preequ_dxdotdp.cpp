
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void dxdotdp_histones_15domains_light_preequ(realtype *dxdotdp, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const int ip, const realtype *w, const realtype *dwdp) {
switch (ip) {
  case 0: {
  dxdotdp[1] = -x[1];
  dxdotdp[2] = -x[2];
  dxdotdp[3] = -x[3];
  dxdotdp[5] = -x[5];
  dxdotdp[6] = -x[6];
  dxdotdp[7] = -x[7];
  dxdotdp[9] = -x[9];
  dxdotdp[10] = -x[10];
  dxdotdp[11] = -x[11];
  dxdotdp[13] = -x[13];
  dxdotdp[14] = -x[14];
  dxdotdp[15] = x[1];
  dxdotdp[16] = x[2];
  dxdotdp[17] = x[3];
  dxdotdp[18] = x[5];
  dxdotdp[19] = x[6];
  dxdotdp[20] = x[7];
  dxdotdp[21] = x[9];
  dxdotdp[22] = x[10];
  dxdotdp[23] = x[11];
  dxdotdp[24] = x[13];
  dxdotdp[25] = x[14];

  } break;

  case 1: {
  dxdotdp[4] = -x[4];
  dxdotdp[5] = -x[5];
  dxdotdp[6] = -x[6];
  dxdotdp[7] = -x[7];
  dxdotdp[8] = -x[8];
  dxdotdp[9] = -x[9];
  dxdotdp[10] = -x[10];
  dxdotdp[11] = -x[11];
  dxdotdp[12] = -x[12];
  dxdotdp[13] = -x[13];
  dxdotdp[14] = -x[14];
  dxdotdp[36] = x[4];
  dxdotdp[37] = x[5];
  dxdotdp[38] = x[6];
  dxdotdp[39] = x[7];
  dxdotdp[40] = x[8];
  dxdotdp[41] = x[9];
  dxdotdp[42] = x[10];
  dxdotdp[43] = x[11];
  dxdotdp[44] = x[12];
  dxdotdp[45] = x[13];
  dxdotdp[46] = x[14];

  } break;

  case 2: {
  dxdotdp[16] = -x[16];
  dxdotdp[17] = -x[17];
  dxdotdp[19] = -x[19];
  dxdotdp[20] = -x[20];
  dxdotdp[22] = -x[22];
  dxdotdp[23] = -x[23];
  dxdotdp[25] = -x[25];
  dxdotdp[26] = x[16];
  dxdotdp[27] = x[17];
  dxdotdp[28] = x[19];
  dxdotdp[29] = x[20];
  dxdotdp[30] = x[22];
  dxdotdp[31] = x[23];
  dxdotdp[32] = x[25];

  } break;

  case 3: {
  dxdotdp[18] = -x[18];
  dxdotdp[19] = -x[19];
  dxdotdp[20] = -x[20];
  dxdotdp[21] = -x[21];
  dxdotdp[22] = -x[22];
  dxdotdp[23] = -x[23];
  dxdotdp[24] = -x[24];
  dxdotdp[25] = -x[25];
  dxdotdp[47] = x[18];
  dxdotdp[48] = x[19];
  dxdotdp[49] = x[20];
  dxdotdp[50] = x[21];
  dxdotdp[51] = x[22];
  dxdotdp[52] = x[23];
  dxdotdp[53] = x[24];
  dxdotdp[54] = x[25];

  } break;

  case 4: {
  dxdotdp[27] = -x[27];
  dxdotdp[29] = -x[29];
  dxdotdp[31] = -x[31];
  dxdotdp[33] = x[27];
  dxdotdp[34] = x[29];
  dxdotdp[35] = x[31];

  } break;

  case 5: {
  dxdotdp[28] = -x[28];
  dxdotdp[29] = -x[29];
  dxdotdp[30] = -x[30];
  dxdotdp[31] = -x[31];
  dxdotdp[32] = -x[32];
  dxdotdp[55] = x[28];
  dxdotdp[56] = x[29];
  dxdotdp[57] = x[30];
  dxdotdp[58] = x[31];
  dxdotdp[59] = x[32];

  } break;

  case 6: {
  dxdotdp[34] = -x[34];
  dxdotdp[35] = -x[35];
  dxdotdp[60] = x[34];
  dxdotdp[61] = x[35];

  } break;

  case 7: {
  dxdotdp[37] = -x[37];
  dxdotdp[38] = -x[38];
  dxdotdp[39] = -x[39];
  dxdotdp[41] = -x[41];
  dxdotdp[42] = -x[42];
  dxdotdp[43] = -x[43];
  dxdotdp[45] = -x[45];
  dxdotdp[46] = -x[46];
  dxdotdp[47] = x[37];
  dxdotdp[48] = x[38];
  dxdotdp[49] = x[39];
  dxdotdp[50] = x[41];
  dxdotdp[51] = x[42];
  dxdotdp[52] = x[43];
  dxdotdp[53] = x[45];
  dxdotdp[54] = x[46];

  } break;

  case 8: {
  dxdotdp[40] = -x[40];
  dxdotdp[41] = -x[41];
  dxdotdp[42] = -x[42];
  dxdotdp[43] = -x[43];
  dxdotdp[44] = -x[44];
  dxdotdp[45] = -x[45];
  dxdotdp[46] = -x[46];
  dxdotdp[62] = x[40];
  dxdotdp[63] = x[41];
  dxdotdp[64] = x[42];
  dxdotdp[65] = x[43];
  dxdotdp[66] = x[44];
  dxdotdp[67] = x[45];
  dxdotdp[68] = x[46];

  } break;

  case 9: {
  dxdotdp[48] = -x[48];
  dxdotdp[49] = -x[49];
  dxdotdp[51] = -x[51];
  dxdotdp[52] = -x[52];
  dxdotdp[54] = -x[54];
  dxdotdp[55] = x[48];
  dxdotdp[56] = x[49];
  dxdotdp[57] = x[51];
  dxdotdp[58] = x[52];
  dxdotdp[59] = x[54];

  } break;

  case 10: {
  dxdotdp[50] = -x[50];
  dxdotdp[51] = -x[51];
  dxdotdp[52] = -x[52];
  dxdotdp[53] = -x[53];
  dxdotdp[54] = -x[54];
  dxdotdp[69] = x[50];
  dxdotdp[70] = x[51];
  dxdotdp[71] = x[52];
  dxdotdp[72] = x[53];
  dxdotdp[73] = x[54];

  } break;

  case 11: {
  dxdotdp[56] = -x[56];
  dxdotdp[58] = -x[58];
  dxdotdp[60] = x[56];
  dxdotdp[61] = x[58];

  } break;

  case 12: {
  dxdotdp[57] = -x[57];
  dxdotdp[58] = -x[58];
  dxdotdp[59] = -x[59];
  dxdotdp[74] = x[57];
  dxdotdp[75] = x[58];
  dxdotdp[76] = x[59];

  } break;

  case 13: {
  dxdotdp[61] = -x[61];
  dxdotdp[77] = x[61];

  } break;

  case 14: {
  dxdotdp[63] = -x[63];
  dxdotdp[64] = -x[64];
  dxdotdp[65] = -x[65];
  dxdotdp[67] = -x[67];
  dxdotdp[68] = -x[68];
  dxdotdp[69] = x[63];
  dxdotdp[70] = x[64];
  dxdotdp[71] = x[65];
  dxdotdp[72] = x[67];
  dxdotdp[73] = x[68];

  } break;

  case 15: {
  dxdotdp[66] = -x[66];
  dxdotdp[67] = -x[67];
  dxdotdp[68] = -x[68];
  dxdotdp[78] = x[66];
  dxdotdp[79] = x[67];
  dxdotdp[80] = x[68];

  } break;

  case 16: {
  dxdotdp[70] = -x[70];
  dxdotdp[71] = -x[71];
  dxdotdp[73] = -x[73];
  dxdotdp[74] = x[70];
  dxdotdp[75] = x[71];
  dxdotdp[76] = x[73];

  } break;

  case 17: {
  dxdotdp[72] = -x[72];
  dxdotdp[73] = -x[73];
  dxdotdp[81] = x[72];
  dxdotdp[82] = x[73];

  } break;

  case 18: {
  dxdotdp[75] = -x[75];
  dxdotdp[77] = x[75];

  } break;

  case 19: {
  dxdotdp[76] = -x[76];
  dxdotdp[83] = x[76];

  } break;

  case 20: {
  dxdotdp[79] = -x[79];
  dxdotdp[80] = -x[80];
  dxdotdp[81] = x[79];
  dxdotdp[82] = x[80];

  } break;

  case 21: {
  dxdotdp[82] = -x[82];
  dxdotdp[83] = x[82];

  } break;

  case 22: {
  dxdotdp[0] = -x[0]+1.0;
  dxdotdp[1] = -x[1]+1.0;
  dxdotdp[2] = -x[2]+1.0;
  dxdotdp[3] = -x[3]+1.0;
  dxdotdp[4] = -x[4]+1.0;
  dxdotdp[5] = -x[5]+1.0;
  dxdotdp[6] = -x[6]+1.0;
  dxdotdp[7] = -x[7]+1.0;
  dxdotdp[8] = -x[8]+1.0;
  dxdotdp[9] = -x[9]+1.0;
  dxdotdp[10] = -x[10]+1.0;
  dxdotdp[11] = -x[11]+1.0;
  dxdotdp[12] = -x[12]+1.0;
  dxdotdp[13] = -x[13]+1.0;
  dxdotdp[14] = -x[14]+1.0;
  dxdotdp[15] = -x[15];
  dxdotdp[16] = -x[16];
  dxdotdp[17] = -x[17];
  dxdotdp[18] = -x[18];
  dxdotdp[19] = -x[19];
  dxdotdp[20] = -x[20];
  dxdotdp[21] = -x[21];
  dxdotdp[22] = -x[22];
  dxdotdp[23] = -x[23];
  dxdotdp[24] = -x[24];
  dxdotdp[25] = -x[25];
  dxdotdp[26] = -x[26];
  dxdotdp[27] = -x[27];
  dxdotdp[28] = -x[28];
  dxdotdp[29] = -x[29];
  dxdotdp[30] = -x[30];
  dxdotdp[31] = -x[31];
  dxdotdp[32] = -x[32];
  dxdotdp[33] = -x[33];
  dxdotdp[34] = -x[34];
  dxdotdp[35] = -x[35];
  dxdotdp[36] = -x[36];
  dxdotdp[37] = -x[37];
  dxdotdp[38] = -x[38];
  dxdotdp[39] = -x[39];
  dxdotdp[40] = -x[40];
  dxdotdp[41] = -x[41];
  dxdotdp[42] = -x[42];
  dxdotdp[43] = -x[43];
  dxdotdp[44] = -x[44];
  dxdotdp[45] = -x[45];
  dxdotdp[46] = -x[46];
  dxdotdp[47] = -x[47];
  dxdotdp[48] = -x[48];
  dxdotdp[49] = -x[49];
  dxdotdp[50] = -x[50];
  dxdotdp[51] = -x[51];
  dxdotdp[52] = -x[52];
  dxdotdp[53] = -x[53];
  dxdotdp[54] = -x[54];
  dxdotdp[55] = -x[55];
  dxdotdp[56] = -x[56];
  dxdotdp[57] = -x[57];
  dxdotdp[58] = -x[58];
  dxdotdp[59] = -x[59];
  dxdotdp[60] = -x[60];
  dxdotdp[61] = -x[61];
  dxdotdp[62] = -x[62];
  dxdotdp[63] = -x[63];
  dxdotdp[64] = -x[64];
  dxdotdp[65] = -x[65];
  dxdotdp[66] = -x[66];
  dxdotdp[67] = -x[67];
  dxdotdp[68] = -x[68];
  dxdotdp[69] = -x[69];
  dxdotdp[70] = -x[70];
  dxdotdp[71] = -x[71];
  dxdotdp[72] = -x[72];
  dxdotdp[73] = -x[73];
  dxdotdp[74] = -x[74];
  dxdotdp[75] = -x[75];
  dxdotdp[76] = -x[76];
  dxdotdp[77] = -x[77];
  dxdotdp[78] = -x[78];
  dxdotdp[79] = -x[79];
  dxdotdp[80] = -x[80];
  dxdotdp[81] = -x[81];
  dxdotdp[82] = -x[82];
  dxdotdp[83] = -x[83];

  } break;

}
}

