#ifndef _amici_wrapfunctions_h
#define _amici_wrapfunctions_h

#include "histonesXenopusHUA_d_r1r2r3.h"

std::unique_ptr<amici::Model> getModel();

#endif /* _amici_wrapfunctions_h */
