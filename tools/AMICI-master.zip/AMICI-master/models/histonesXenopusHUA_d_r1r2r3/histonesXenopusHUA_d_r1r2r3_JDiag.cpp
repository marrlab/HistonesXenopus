
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void JDiag_histonesXenopusHUA_d_r1r2r3(realtype *JDiag, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w, const realtype *dwdx) {
  JDiag[0+0*4] = -p[1];
  JDiag[1+0*4] = -p[2]-p[4];
  JDiag[2+0*4] = -p[3]-p[4];
  JDiag[3+0*4] = -dwdx[0];
}

