
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void J_histonesXenopusHUA_d_r1r2r3(realtype *J, const realtype t, const realtype *x, const double *p, const double *k, const realtype *h, const realtype *w, const realtype *dwdx) {
  J[0+0*4] = -p[1];
  J[0+1*4] = p[4];
  J[1+0*4] = p[1];
  J[1+1*4] = -p[2]-p[4];
  J[1+2*4] = p[4];
  J[2+1*4] = p[2];
  J[2+2*4] = -p[3]-p[4];
  J[2+3*4] = dwdx[0];
  J[3+2*4] = p[3];
  J[3+3*4] = -dwdx[0];
}

