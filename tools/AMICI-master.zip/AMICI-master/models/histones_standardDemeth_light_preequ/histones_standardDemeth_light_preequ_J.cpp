
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void J_histones_standardDemeth_light_preequ(realtype *J, const realtype t, const realtype *x, const double *p, const double *k, const realtype *h, const realtype *w, const realtype *dwdx) {
  J[0+0*15] = -p[0]-p[7]-p[8];
  J[0+1*15] = dwdx[0];
  J[0+4*15] = dwdx[3];
  J[1+0*15] = p[7];
  J[1+1*15] = -p[0]-p[9]-p[10]-dwdx[0];
  J[1+2*15] = dwdx[1];
  J[1+5*15] = dwdx[4];
  J[2+1*15] = p[9];
  J[2+2*15] = -p[0]-p[11]-p[12]-dwdx[1];
  J[2+3*15] = dwdx[2];
  J[2+6*15] = dwdx[6];
  J[3+2*15] = p[11];
  J[3+3*15] = -p[0]-p[13]-dwdx[2];
  J[3+7*15] = dwdx[8];
  J[4+0*15] = p[8];
  J[4+4*15] = -p[0]-p[14]-p[15]-dwdx[3];
  J[4+5*15] = dwdx[5];
  J[4+8*15] = dwdx[10];
  J[5+1*15] = p[10];
  J[5+4*15] = p[14];
  J[5+5*15] = -p[0]-p[16]-p[17]-dwdx[4]-dwdx[5];
  J[5+6*15] = dwdx[7];
  J[5+9*15] = dwdx[11];
  J[6+2*15] = p[12];
  J[6+5*15] = p[16];
  J[6+6*15] = -p[0]-p[18]-p[19]-dwdx[6]-dwdx[7];
  J[6+7*15] = dwdx[9];
  J[6+10*15] = dwdx[13];
  J[7+3*15] = p[13];
  J[7+6*15] = p[18];
  J[7+7*15] = -p[0]-p[20]-dwdx[8]-dwdx[9];
  J[7+11*15] = dwdx[15];
  J[8+4*15] = p[15];
  J[8+8*15] = -p[0]-p[21]-p[22]-dwdx[10];
  J[8+9*15] = dwdx[12];
  J[8+12*15] = dwdx[17];
  J[9+5*15] = p[17];
  J[9+8*15] = p[21];
  J[9+9*15] = -p[0]-p[23]-p[24]-dwdx[11]-dwdx[12];
  J[9+10*15] = dwdx[14];
  J[9+13*15] = dwdx[18];
  J[10+6*15] = p[19];
  J[10+9*15] = p[23];
  J[10+10*15] = -p[0]-p[25]-p[26]-dwdx[13]-dwdx[14];
  J[10+11*15] = dwdx[16];
  J[10+14*15] = dwdx[20];
  J[11+7*15] = p[20];
  J[11+10*15] = p[25];
  J[11+11*15] = -p[0]-dwdx[15]-dwdx[16];
  J[12+8*15] = p[22];
  J[12+12*15] = -p[0]-p[27]-dwdx[17];
  J[12+13*15] = dwdx[19];
  J[13+9*15] = p[24];
  J[13+12*15] = p[27];
  J[13+13*15] = -p[0]-p[28]-dwdx[18]-dwdx[19];
  J[13+14*15] = dwdx[21];
  J[14+10*15] = p[26];
  J[14+13*15] = p[28];
  J[14+14*15] = -p[0]-dwdx[20]-dwdx[21];
}

