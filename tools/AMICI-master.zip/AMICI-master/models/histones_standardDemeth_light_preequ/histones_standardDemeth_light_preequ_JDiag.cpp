
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void JDiag_histones_standardDemeth_light_preequ(realtype *JDiag, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w, const realtype *dwdx) {
  JDiag[0+0*15] = -p[0]-p[7]-p[8];
  JDiag[1+0*15] = -p[0]-p[9]-p[10]-dwdx[0];
  JDiag[2+0*15] = -p[0]-p[11]-p[12]-dwdx[1];
  JDiag[3+0*15] = -p[0]-p[13]-dwdx[2];
  JDiag[4+0*15] = -p[0]-p[14]-p[15]-dwdx[3];
  JDiag[5+0*15] = -p[0]-p[16]-p[17]-dwdx[4]-dwdx[5];
  JDiag[6+0*15] = -p[0]-p[18]-p[19]-dwdx[6]-dwdx[7];
  JDiag[7+0*15] = -p[0]-p[20]-dwdx[8]-dwdx[9];
  JDiag[8+0*15] = -p[0]-p[21]-p[22]-dwdx[10];
  JDiag[9+0*15] = -p[0]-p[23]-p[24]-dwdx[11]-dwdx[12];
  JDiag[10+0*15] = -p[0]-p[25]-p[26]-dwdx[13]-dwdx[14];
  JDiag[11+0*15] = -p[0]-dwdx[15]-dwdx[16];
  JDiag[12+0*15] = -p[0]-p[27]-dwdx[17];
  JDiag[13+0*15] = -p[0]-p[28]-dwdx[18]-dwdx[19];
  JDiag[14+0*15] = -p[0]-dwdx[20]-dwdx[21];
}

