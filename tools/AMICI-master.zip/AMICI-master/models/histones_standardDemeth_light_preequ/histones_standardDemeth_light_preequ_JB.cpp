
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void JB_histones_standardDemeth_light_preequ(realtype *JB, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *xB, const realtype *w, const realtype *dwdx) {
  JB[0+0*15] = p[0]+p[7]+p[8];
  JB[0+1*15] = -p[7];
  JB[0+4*15] = -p[8];
  JB[1+0*15] = -dwdx[0];
  JB[1+1*15] = p[0]+p[9]+p[10]+dwdx[0];
  JB[1+2*15] = -p[9];
  JB[1+5*15] = -p[10];
  JB[2+1*15] = -dwdx[1];
  JB[2+2*15] = p[0]+p[11]+p[12]+dwdx[1];
  JB[2+3*15] = -p[11];
  JB[2+6*15] = -p[12];
  JB[3+2*15] = -dwdx[2];
  JB[3+3*15] = p[0]+p[13]+dwdx[2];
  JB[3+7*15] = -p[13];
  JB[4+0*15] = -dwdx[3];
  JB[4+4*15] = p[0]+p[14]+p[15]+dwdx[3];
  JB[4+5*15] = -p[14];
  JB[4+8*15] = -p[15];
  JB[5+1*15] = -dwdx[4];
  JB[5+4*15] = -dwdx[5];
  JB[5+5*15] = p[0]+p[16]+p[17]+dwdx[4]+dwdx[5];
  JB[5+6*15] = -p[16];
  JB[5+9*15] = -p[17];
  JB[6+2*15] = -dwdx[6];
  JB[6+5*15] = -dwdx[7];
  JB[6+6*15] = p[0]+p[18]+p[19]+dwdx[6]+dwdx[7];
  JB[6+7*15] = -p[18];
  JB[6+10*15] = -p[19];
  JB[7+3*15] = -dwdx[8];
  JB[7+6*15] = -dwdx[9];
  JB[7+7*15] = p[0]+p[20]+dwdx[8]+dwdx[9];
  JB[7+11*15] = -p[20];
  JB[8+4*15] = -dwdx[10];
  JB[8+8*15] = p[0]+p[21]+p[22]+dwdx[10];
  JB[8+9*15] = -p[21];
  JB[8+12*15] = -p[22];
  JB[9+5*15] = -dwdx[11];
  JB[9+8*15] = -dwdx[12];
  JB[9+9*15] = p[0]+p[23]+p[24]+dwdx[11]+dwdx[12];
  JB[9+10*15] = -p[23];
  JB[9+13*15] = -p[24];
  JB[10+6*15] = -dwdx[13];
  JB[10+9*15] = -dwdx[14];
  JB[10+10*15] = p[0]+p[25]+p[26]+dwdx[13]+dwdx[14];
  JB[10+11*15] = -p[25];
  JB[10+14*15] = -p[26];
  JB[11+7*15] = -dwdx[15];
  JB[11+10*15] = -dwdx[16];
  JB[11+11*15] = p[0]+dwdx[15]+dwdx[16];
  JB[12+8*15] = -dwdx[17];
  JB[12+12*15] = p[0]+p[27]+dwdx[17];
  JB[12+13*15] = -p[27];
  JB[13+9*15] = -dwdx[18];
  JB[13+12*15] = -dwdx[19];
  JB[13+13*15] = p[0]+p[28]+dwdx[18]+dwdx[19];
  JB[13+14*15] = -p[28];
  JB[14+10*15] = -dwdx[20];
  JB[14+13*15] = -dwdx[21];
  JB[14+14*15] = p[0]+dwdx[20]+dwdx[21];
}

