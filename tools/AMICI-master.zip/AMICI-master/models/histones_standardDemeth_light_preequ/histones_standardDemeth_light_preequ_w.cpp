
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void w_histones_standardDemeth_light_preequ(realtype *w, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *tcl) {
  w[0] = p[4]*x[1];
  w[1] = p[5]*x[2];
  w[2] = p[6]*x[3];
  w[3] = p[1]*x[4];
  w[4] = p[1]*x[5];
  w[5] = p[4]*x[5];
  w[6] = p[1]*x[6];
  w[7] = p[5]*x[6];
  w[8] = p[1]*x[7];
  w[9] = p[6]*x[7];
  w[10] = p[2]*x[8];
  w[11] = p[2]*x[9];
  w[12] = p[4]*x[9];
  w[13] = p[2]*x[10];
  w[14] = p[5]*x[10];
  w[15] = p[2]*x[11];
  w[16] = p[6]*x[11];
  w[17] = p[3]*x[12];
  w[18] = p[3]*x[13];
  w[19] = p[4]*x[13];
  w[20] = p[3]*x[14];
  w[21] = p[5]*x[14];
}

