
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void dxdotdp_histones_standardDemeth_light_preequ(realtype *dxdotdp, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const int ip, const realtype *w, const realtype *dwdp) {
switch (ip) {
  case 0: {
  dxdotdp[0] = -x[0]+1.0;
  dxdotdp[1] = -x[1];
  dxdotdp[2] = -x[2];
  dxdotdp[3] = -x[3];
  dxdotdp[4] = -x[4];
  dxdotdp[5] = -x[5];
  dxdotdp[6] = -x[6];
  dxdotdp[7] = -x[7];
  dxdotdp[8] = -x[8];
  dxdotdp[9] = -x[9];
  dxdotdp[10] = -x[10];
  dxdotdp[11] = -x[11];
  dxdotdp[12] = -x[12];
  dxdotdp[13] = -x[13];
  dxdotdp[14] = -x[14];

  } break;

  case 1: {
  dxdotdp[0] = dwdp[0];
  dxdotdp[1] = dwdp[1];
  dxdotdp[2] = dwdp[2];
  dxdotdp[3] = dwdp[3];
  dxdotdp[4] = -dwdp[0];
  dxdotdp[5] = -dwdp[1];
  dxdotdp[6] = -dwdp[2];
  dxdotdp[7] = -dwdp[3];

  } break;

  case 2: {
  dxdotdp[4] = dwdp[4];
  dxdotdp[5] = dwdp[5];
  dxdotdp[6] = dwdp[6];
  dxdotdp[7] = dwdp[7];
  dxdotdp[8] = -dwdp[4];
  dxdotdp[9] = -dwdp[5];
  dxdotdp[10] = -dwdp[6];
  dxdotdp[11] = -dwdp[7];

  } break;

  case 3: {
  dxdotdp[8] = dwdp[8];
  dxdotdp[9] = dwdp[9];
  dxdotdp[10] = dwdp[10];
  dxdotdp[12] = -dwdp[8];
  dxdotdp[13] = -dwdp[9];
  dxdotdp[14] = -dwdp[10];

  } break;

  case 4: {
  dxdotdp[0] = dwdp[11];
  dxdotdp[1] = -dwdp[11];
  dxdotdp[4] = dwdp[12];
  dxdotdp[5] = -dwdp[12];
  dxdotdp[8] = dwdp[13];
  dxdotdp[9] = -dwdp[13];
  dxdotdp[12] = dwdp[14];
  dxdotdp[13] = -dwdp[14];

  } break;

  case 5: {
  dxdotdp[1] = dwdp[15];
  dxdotdp[2] = -dwdp[15];
  dxdotdp[5] = dwdp[16];
  dxdotdp[6] = -dwdp[16];
  dxdotdp[9] = dwdp[17];
  dxdotdp[10] = -dwdp[17];
  dxdotdp[13] = dwdp[18];
  dxdotdp[14] = -dwdp[18];

  } break;

  case 6: {
  dxdotdp[2] = dwdp[19];
  dxdotdp[3] = -dwdp[19];
  dxdotdp[6] = dwdp[20];
  dxdotdp[7] = -dwdp[20];
  dxdotdp[10] = dwdp[21];
  dxdotdp[11] = -dwdp[21];

  } break;

  case 7: {
  dxdotdp[0] = -x[0];
  dxdotdp[1] = x[0];

  } break;

  case 8: {
  dxdotdp[0] = -x[0];
  dxdotdp[4] = x[0];

  } break;

  case 9: {
  dxdotdp[1] = -x[1];
  dxdotdp[2] = x[1];

  } break;

  case 10: {
  dxdotdp[1] = -x[1];
  dxdotdp[5] = x[1];

  } break;

  case 11: {
  dxdotdp[2] = -x[2];
  dxdotdp[3] = x[2];

  } break;

  case 12: {
  dxdotdp[2] = -x[2];
  dxdotdp[6] = x[2];

  } break;

  case 13: {
  dxdotdp[3] = -x[3];
  dxdotdp[7] = x[3];

  } break;

  case 14: {
  dxdotdp[4] = -x[4];
  dxdotdp[5] = x[4];

  } break;

  case 15: {
  dxdotdp[4] = -x[4];
  dxdotdp[8] = x[4];

  } break;

  case 16: {
  dxdotdp[5] = -x[5];
  dxdotdp[6] = x[5];

  } break;

  case 17: {
  dxdotdp[5] = -x[5];
  dxdotdp[9] = x[5];

  } break;

  case 18: {
  dxdotdp[6] = -x[6];
  dxdotdp[7] = x[6];

  } break;

  case 19: {
  dxdotdp[6] = -x[6];
  dxdotdp[10] = x[6];

  } break;

  case 20: {
  dxdotdp[7] = -x[7];
  dxdotdp[11] = x[7];

  } break;

  case 21: {
  dxdotdp[8] = -x[8];
  dxdotdp[9] = x[8];

  } break;

  case 22: {
  dxdotdp[8] = -x[8];
  dxdotdp[12] = x[8];

  } break;

  case 23: {
  dxdotdp[9] = -x[9];
  dxdotdp[10] = x[9];

  } break;

  case 24: {
  dxdotdp[9] = -x[9];
  dxdotdp[13] = x[9];

  } break;

  case 25: {
  dxdotdp[10] = -x[10];
  dxdotdp[11] = x[10];

  } break;

  case 26: {
  dxdotdp[10] = -x[10];
  dxdotdp[14] = x[10];

  } break;

  case 27: {
  dxdotdp[12] = -x[12];
  dxdotdp[13] = x[12];

  } break;

  case 28: {
  dxdotdp[13] = -x[13];
  dxdotdp[14] = x[13];

  } break;

}
}

