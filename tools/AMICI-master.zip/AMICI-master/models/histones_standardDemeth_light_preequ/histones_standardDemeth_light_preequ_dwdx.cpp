
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void dwdx_histones_standardDemeth_light_preequ(realtype *dwdx, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w, const realtype *tcl) {
  dwdx[0] = p[4];
  dwdx[1] = p[5];
  dwdx[2] = p[6];
  dwdx[3] = p[1];
  dwdx[4] = p[1];
  dwdx[5] = p[4];
  dwdx[6] = p[1];
  dwdx[7] = p[5];
  dwdx[8] = p[1];
  dwdx[9] = p[6];
  dwdx[10] = p[2];
  dwdx[11] = p[2];
  dwdx[12] = p[4];
  dwdx[13] = p[2];
  dwdx[14] = p[5];
  dwdx[15] = p[2];
  dwdx[16] = p[6];
  dwdx[17] = p[3];
  dwdx[18] = p[3];
  dwdx[19] = p[4];
  dwdx[20] = p[3];
  dwdx[21] = p[5];
}

