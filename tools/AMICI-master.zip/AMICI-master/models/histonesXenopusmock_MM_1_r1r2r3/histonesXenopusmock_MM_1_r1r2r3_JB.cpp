
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void JB_histonesXenopusmock_MM_1_r1r2r3(realtype *JB, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *xB, const realtype *w, const realtype *dwdx) {
  JB[0+0*4] = p[5]+w[5]*w[10]-6.243314768165359E15/((t*p[0]*9.007199254740992E15)/w[0]+4.503599627370496E15);
  JB[0+1*4] = -p[5];
  JB[1+0*4] = -6.243314768165359E15/((t*p[0]*9.007199254740992E15)/w[0]+4.503599627370496E15);
  JB[1+1*4] = p[6]+w[5]*w[10];
  JB[1+2*4] = -p[6];
  JB[2+0*4] = -6.243314768165359E15/((t*p[0]*9.007199254740992E15)/w[0]+4.503599627370496E15);
  JB[2+2*4] = p[7]+w[5]*w[10];
  JB[2+3*4] = -p[7];
  JB[3+0*4] = -6.243314768165359E15/((t*p[0]*9.007199254740992E15)/w[0]+4.503599627370496E15);
  JB[3+3*4] = w[5]*w[10];
}

