
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void xdot_histonesXenopusmock_MM_1_r1r2r3(realtype *xdot, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w) {
  xdot[0] = -p[5]*x[0]+(x[0]*6.243314768165359E15+x[1]*6.243314768165359E15+x[2]*6.243314768165359E15+x[3]*6.243314768165359E15)/((t*p[0]*9.007199254740992E15)/w[0]+4.503599627370496E15)-x[0]*w[5]*w[10];
  xdot[1] = p[5]*x[0]-p[6]*x[1]-x[1]*w[5]*w[10];
  xdot[2] = p[6]*x[1]-p[7]*x[2]-x[2]*w[5]*w[10];
  xdot[3] = p[7]*x[2]-x[3]*w[5]*w[10];
}

