
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void dwdp_histonesXenopusmock_MM_1_r1r2r3(realtype *dwdp, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w, const realtype *tcl, const realtype *stcl) {
  dwdp[0] = 1.0;
  dwdp[1] = w[1]*6.931471805599453E-1;
  dwdp[2] = w[0]*dwdp[0]*2.0;
  dwdp[3] = dwdp[2]*3.465735902799726E-1;
  dwdp[4] = dwdp[1]+dwdp[3];
  dwdp[5] = 1.0/2.0;
  dwdp[6] = t;
  dwdp[7] = dwdp[5]+dwdp[6];
  dwdp[8] = 1.0/(w[9]*w[9]*w[9])*dwdp[7]*-2.0;
}

