
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void sx0_histonesXenopusmock_MM_1_r1r2r3(realtype *sx0, const realtype t,const realtype *x0, const realtype *p, const realtype *k, const int ip) {
switch (ip) {
  case 1: {
  sx0[0] = 1.0/pow(p[1]+p[2]+p[3]+1.0/1.0E1,2.0)*(-1.0/1.0E1);
  sx0[1] = 1.0/(p[1]+p[2]+p[3]+1.0/1.0E1)-p[1]*1.0/pow(p[1]+p[2]+p[3]+1.0/1.0E1,2.0);
  sx0[2] = -p[2]*1.0/pow(p[1]+p[2]+p[3]+1.0/1.0E1,2.0);
  sx0[3] = -p[3]*1.0/pow(p[1]+p[2]+p[3]+1.0/1.0E1,2.0);

  } break;

  case 2: {
  sx0[0] = 1.0/pow(p[1]+p[2]+p[3]+1.0/1.0E1,2.0)*(-1.0/1.0E1);
  sx0[1] = -p[1]*1.0/pow(p[1]+p[2]+p[3]+1.0/1.0E1,2.0);
  sx0[2] = 1.0/(p[1]+p[2]+p[3]+1.0/1.0E1)-p[2]*1.0/pow(p[1]+p[2]+p[3]+1.0/1.0E1,2.0);
  sx0[3] = -p[3]*1.0/pow(p[1]+p[2]+p[3]+1.0/1.0E1,2.0);

  } break;

  case 3: {
  sx0[0] = 1.0/pow(p[1]+p[2]+p[3]+1.0/1.0E1,2.0)*(-1.0/1.0E1);
  sx0[1] = -p[1]*1.0/pow(p[1]+p[2]+p[3]+1.0/1.0E1,2.0);
  sx0[2] = -p[2]*1.0/pow(p[1]+p[2]+p[3]+1.0/1.0E1,2.0);
  sx0[3] = 1.0/(p[1]+p[2]+p[3]+1.0/1.0E1)-p[3]*1.0/pow(p[1]+p[2]+p[3]+1.0/1.0E1,2.0);

  } break;

}
}

