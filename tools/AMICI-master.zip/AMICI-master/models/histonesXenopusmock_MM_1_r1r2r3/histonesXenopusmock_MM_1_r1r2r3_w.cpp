
#include "amici/symbolic_functions.h"
#include "amici/defines.h" //realtype definition
typedef amici::realtype realtype;
#include <cmath> 

using namespace amici;

void w_histonesXenopusmock_MM_1_r1r2r3(realtype *w, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *tcl) {
  w[0] = t+p[0];
  w[1] = t*t;
  w[2] = p[0]*w[1]*6.931471805599453E-1;
  w[3] = w[0]*w[0];
  w[4] = w[3]*3.465735902799726E-1;
  w[5] = w[2]+w[4];
  w[6] = t*(1.0/2.0);
  w[7] = p[0]*(1.0/2.0);
  w[8] = t*p[0];
  w[9] = w[6]+w[7]+w[8];
  w[10] = 1.0/(w[9]*w[9]);
}

