# FAQ

__Q__: My model fails to build.

__A__: Remove the corresponding model directory located in AMICI/models/*yourmodelname* and compile again.

---

__Q__: It still does not compile.

__A__: Make an [issue](https://github.com/ICB-DCM/AMICI/issues) and we will have a look.

---

__Q__: I get an out of memory error while compiling my model on a Windows machine.

__A__: This may be due to an old compiler version. See [issue #161](https://github.com/ICB-DCM/AMICI/issues/161) for instructions on how to install a new compiler.

---

__Q__: The simulation/sensitivities I get are incorrect.

__A__: There are some known issues, especially with adjoint sensitivities, events and DAEs. If your particular problem is not featured in the [issues](https://github.com/ICB-DCM/AMICI/issues) list, please add it!

