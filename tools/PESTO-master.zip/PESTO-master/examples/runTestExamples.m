function runTestExamples()
% runTestExamples runs some examples for the PESTO toolbox, to test if new
% implementations cause problems

mainConversionReaction;
mainEnzymaticCatalysis;
mainTransfection;
mainErbBSignaling;
mainJakstatSignaling;

end