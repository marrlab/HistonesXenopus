[exdir,~,~]=fileparts(which('BachmannJakStat_syms.m'));
amiwrap('BachmannJakStat','BachmannJakStat_syms',exdir)
amiwrap('BachmannJakStat_SHP1oe','BachmannJakStat_SHP1oe_syms',exdir)